import nodemailer, {} from 'nodemailer';
import { env } from '../config/env.js';
import { logger } from '../config/logger.js';
import { AppError } from './app-error.js';
function parseEmailFrom(from) {
    const match = from.match(/^(.*?)<([^>]+)>$/);
    if (match && match[1] && match[2]) {
        return { name: match[1].trim().replace(/^"|"$/g, ''), email: match[2].trim() };
    }
    return { email: from.trim() };
}
let transporter;
function getTransporter() {
    const missing = [
        !env.MAILCOW_SMTP_HOST ? 'MAILCOW_SMTP_HOST' : null,
        !env.MAILCOW_SMTP_USER ? 'MAILCOW_SMTP_USER' : null,
        !env.MAILCOW_SMTP_PASS ? 'MAILCOW_SMTP_PASS' : null,
        !env.EMAIL_FROM ? 'EMAIL_FROM' : null,
    ].filter((value) => Boolean(value));
    if (missing.length > 0) {
        throw new AppError(503, 'MAILCOW_SMTP_CONFIGURATION_MISSING', 'Mailcow SMTP configuration is incomplete', { missingEnv: missing });
    }
    if (!transporter) {
        transporter = nodemailer.createTransport({
            host: env.MAILCOW_SMTP_HOST,
            port: env.MAILCOW_SMTP_PORT,
            secure: env.MAILCOW_SMTP_SECURE,
            auth: { user: env.MAILCOW_SMTP_USER, pass: env.MAILCOW_SMTP_PASS },
        });
    }
    return transporter;
}
export async function sendMail(to, subject, html, attachments = []) {
    const sender = parseEmailFrom(env.EMAIL_FROM || '');
    try {
        await getTransporter().sendMail({
            from: sender.name ? `${sender.name} <${sender.email}>` : sender.email,
            to,
            subject,
            html,
            attachments,
        });
    }
    catch (error) {
        if (error instanceof AppError)
            throw error;
        throw new AppError(502, 'MAILCOW_SMTP_SEND_FAILED', 'Mailcow rejected the outgoing email', {
            recipient: to,
            subject,
            attachmentCount: attachments.length,
            providerMessage: error instanceof Error ? error.message : 'unknown_error',
        });
    }
    logger.info({ to, subject, attachmentCount: attachments.length }, 'Email sent via Mailcow SMTP');
}
export async function sendOtpEmail(to, code) {
    const html = `<p>Your Lulu AI verification code is:</p><h2>${code}</h2><p>This code expires soon.</p>`;
    await sendMail(to, 'Your Lulu AI verification code', html);
}
export async function sendResetEmail(to, code) {
    const html = `<p>Use this Lulu AI code to reset your password:</p><h2>${code}</h2><p>This code expires soon.</p>`;
    await sendMail(to, 'Reset your Lulu AI password', html);
}
function escapeHtml(value) {
    return value.replace(/[&<>'"]/g, (character) => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        "'": '&#39;',
        '"': '&quot;',
    })[character]);
}
export async function sendWorkspaceInvitationEmail(to, workspaceName, invitationUrl) {
    const safeWorkspaceName = escapeHtml(workspaceName);
    const safeUrl = escapeHtml(invitationUrl);
    const html = [
        `<p>You have been invited to join <strong>${safeWorkspaceName}</strong> in Lulu AI.</p>`,
        `<p><a href="${safeUrl}">Accept workspace invitation</a></p>`,
        '<p>This invitation expires in seven days.</p>',
    ].join('');
    await sendMail(to, `Join ${workspaceName} in Lulu AI`, html);
}
//# sourceMappingURL=mailer.js.map