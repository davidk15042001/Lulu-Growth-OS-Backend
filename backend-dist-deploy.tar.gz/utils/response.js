export function sendResponse(res, status, message, data = null) {
    const body = {
        success: status >= 200 && status < 300,
        message,
        data,
    };
    return res.status(status).json(body);
}
export function successResponse(res, message, data = null) {
    return sendResponse(res, 200, message, data);
}
export function createdResponse(res, message, data = null) {
    return sendResponse(res, 201, message, data);
}
export function errorResponse(res, status, message) {
    return jsonError(res, status, 'REQUEST_ERROR', message);
}
export function jsonError(res, status, code, message) {
    const body = { success: false, error: { code, message } };
    return res.status(status).json(body);
}
export function unauthorized(res, errorMessage = 'Authentication required') {
    return jsonError(res, 401, 'UNAUTHORIZED', errorMessage);
}
export function forbidden(res, errorMessage = 'Forbidden') {
    return jsonError(res, 403, 'FORBIDDEN', errorMessage);
}
export function notFoundError(res, errorMessage = 'Resource not found') {
    return jsonError(res, 404, 'NOT_FOUND', errorMessage);
}
export function tooManyRequests(res, errorMessage) {
    return jsonError(res, 429, 'TOO_MANY_REQUESTS', errorMessage ?? 'Der Login ist vorübergehend pausiert. Bitte warten Sie kurz und versuchen Sie es erneut.');
}
//# sourceMappingURL=response.js.map