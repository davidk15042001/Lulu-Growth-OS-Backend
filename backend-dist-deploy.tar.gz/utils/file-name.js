const MOJIBAKE_MARKERS = /[ÃÂâð�]/;
export function normalizeUploadedFileName(value) {
    const trimmed = value.trim();
    if (!MOJIBAKE_MARKERS.test(trimmed))
        return trimmed;
    const decoded = Buffer.from(trimmed, 'latin1').toString('utf8');
    return decoded.includes('\uFFFD') ? trimmed : decoded;
}
export function sanitizeUploadedFileName(value) {
    return normalizeUploadedFileName(value)
        .replace(/[\u0000-\u001f\u007f]/g, '')
        .trim()
        .slice(0, 255);
}
//# sourceMappingURL=file-name.js.map