import { jsonError } from '../utils/response.js';
export function methodNotAllowed(_req, res) {
    return jsonError(res, 405, 'METHOD_NOT_ALLOWED', 'Method not allowed');
}
//# sourceMappingURL=methodNotAllowed.middleware.js.map