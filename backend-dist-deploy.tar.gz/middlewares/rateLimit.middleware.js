import rateLimit from 'express-rate-limit';
import { query } from '../db/pool.js';
import { tooManyRequests } from '../utils/response.js';
export function dbRateLimit(opts) {
    const { keyPrefix, windowMs, limit, message } = opts;
    return async function dbRateLimitMiddleware(req, res, next) {
        try {
            const ip = (req.ip || req.headers['x-forwarded-for'] || req.socket.remoteAddress);
            const userId = req.user?.id;
            const identifier = userId ? `user:${userId}` : `ip:${ip}`;
            const key = `${keyPrefix}:${identifier}`;
            const windowStart = new Date(Math.floor(Date.now() / windowMs) * windowMs).toISOString();
            const { rows } = await query(`INSERT INTO rate_limits (key, window_start, count, created_at, updated_at)
         VALUES ($1, $2, 1, NOW(), NOW())
         ON CONFLICT (key, window_start)
         DO UPDATE SET count = rate_limits.count + 1, updated_at = NOW()
         RETURNING count`, [key, windowStart]);
            const current = rows[0]?.count ?? 1;
            if (current > limit) {
                return tooManyRequests(res, message);
            }
            next();
        }
        catch (err) {
            next(err);
        }
    };
}
export async function cleanupRateLimits(olderThanMs = 1000 * 60 * 60 * 24 * 2) {
    const cutoff = new Date(Date.now() - olderThanMs).toISOString();
    await query('DELETE FROM rate_limits WHERE window_start < $1', [cutoff]);
}
export const otpLimiter = rateLimit({
    windowMs: 10 * 60 * 1000,
    max: 20,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    handler: (_req, res) => tooManyRequests(res),
});
//# sourceMappingURL=rateLimit.middleware.js.map