import { notFoundError } from '../utils/response.js';
export function notFound(_req, res) {
    return notFoundError(res);
}
//# sourceMappingURL=notFound.middleware.js.map