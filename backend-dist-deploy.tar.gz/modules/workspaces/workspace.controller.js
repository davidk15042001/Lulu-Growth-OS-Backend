import { createdResponse, successResponse } from '../../utils/response.js';
import * as service from './workspace.service.js';
import { createWorkspaceSchema, updateWorkspaceSchema, workspaceIdParamsSchema, } from './workspace.validator.js';
export async function list(req, res, next) {
    try {
        const workspaces = await service.listWorkspaces(req.user.id);
        return successResponse(res, 'Workspaces loaded', { items: workspaces });
    }
    catch (error) {
        next(error);
    }
}
export async function create(req, res, next) {
    try {
        const input = createWorkspaceSchema.parse(req.body);
        const workspace = await service.createWorkspace(req.user.id, input);
        return createdResponse(res, 'Workspace created', workspace);
    }
    catch (error) {
        next(error);
    }
}
export async function get(req, res, next) {
    try {
        const { workspaceId } = workspaceIdParamsSchema.parse(req.params);
        const workspace = await service.getWorkspace(workspaceId, req.user.id);
        return successResponse(res, 'Workspace loaded', workspace);
    }
    catch (error) {
        next(error);
    }
}
export async function update(req, res, next) {
    try {
        const { workspaceId } = workspaceIdParamsSchema.parse(req.params);
        const input = updateWorkspaceSchema.parse(req.body);
        const workspace = await service.updateWorkspace(workspaceId, req.user.id, input);
        return successResponse(res, 'Workspace updated', workspace);
    }
    catch (error) {
        next(error);
    }
}
//# sourceMappingURL=workspace.controller.js.map