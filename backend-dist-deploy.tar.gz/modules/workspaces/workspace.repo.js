import { query, withTransaction } from '../../db/pool.js';
const workspaceSelect = `
  w.id,
  w.name AS "companyName",
  w.slug,
  w.industry,
  w.company_size AS "companySize",
  w.country_region AS "countryRegion",
  w.business_description AS "businessDescription",
  w.value_proposition AS "valueProposition",
  w.target_market AS "targetMarket",
  w.short_brand_description AS "shortBrandDescription",
  w.positioning_tags AS "positioningTags",
  w.legal_form AS "legalForm",
  w.founding_year AS "foundingYear",
  w.employee_count AS "employeeCount",
  w.annual_revenue_range AS "annualRevenueRange",
  w.business_model_type AS "businessModelType",
  w.company_stage AS "companyStage",
  w.sales_model AS "salesModel",
  w.sales_cycle_days AS "salesCycleDays",
  w.primary_icp AS "primaryIcp",
  w.usp,
  w.mission,
  w.vision,
  w.primary_challenges AS "primaryChallenges",
  w.languages,
  w.regulated_industries AS "regulatedIndustries",
  w.onboarding_step AS "onboardingStep",
  w.onboarding_completed_at AS "onboardingCompletedAt",
  w.onboarding_file_reupload_required AS "onboardingFileReuploadRequired",
  w.onboarding_files_purged_at AS "onboardingFilesPurgedAt",
  w.created_by AS "createdBy",
  w.created_at AS "createdAt",
  w.updated_at AS "updatedAt",
  wm.role,
  COALESCE((SELECT plan_key FROM workspace_subscriptions ws2 WHERE ws2.workspace_id = w.id ORDER BY ws2.updated_at DESC LIMIT 1), 'starter') AS "planKey"
`;
export async function createWorkspace(userId, input, slug) {
    return withTransaction(async (client) => {
        const created = await query(`INSERT INTO workspaces (name, slug, industry, company_size, country_region, created_by)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING id`, [
            input.companyName,
            slug,
            input.industry ?? null,
            input.companySize ?? null,
            input.countryRegion ?? null,
            userId,
        ], client);
        const workspaceId = created.rows[0]?.id;
        if (!workspaceId)
            throw new Error('Workspace insert did not return an id');
        await query(`INSERT INTO workspace_members (workspace_id, user_id, role)
       VALUES ($1, $2, 'owner')`, [workspaceId, userId], client);
        await query(`INSERT INTO workspace_subscriptions (
         workspace_id, plan_key, status, seats, trial_ends_at,
         current_period_starts_at, current_period_ends_at
       ) VALUES ($1, 'starter', 'trialing', 1, NOW() + INTERVAL '14 days', NOW(), NOW() + INTERVAL '1 month')
       ON CONFLICT (workspace_id) DO NOTHING`, [workspaceId], client);
        const workspace = await findWorkspaceForUser(workspaceId, userId, client);
        if (!workspace)
            throw new Error('Created workspace could not be loaded');
        return workspace;
    });
}
export async function listWorkspacesForUser(userId) {
    const { rows } = await query(`SELECT ${workspaceSelect}
     FROM workspaces w
     JOIN workspace_members wm ON wm.workspace_id = w.id
     WHERE wm.user_id = $1 AND w.deleted_at IS NULL
     ORDER BY w.created_at ASC`, [userId]);
    return rows;
}
export async function findWorkspaceForUser(workspaceId, userId, client) {
    const { rows } = await query(`SELECT ${workspaceSelect}
     FROM workspaces w
     JOIN workspace_members wm ON wm.workspace_id = w.id
     WHERE w.id = $1 AND wm.user_id = $2 AND w.deleted_at IS NULL
     LIMIT 1`, [workspaceId, userId], client);
    return rows[0];
}
export async function findWorkspaceById(workspaceId) {
    const { rows } = await query(`SELECT w.id, w.name AS "companyName", w.slug, w.industry, w.company_size AS "companySize",
            w.country_region AS "countryRegion", w.business_description AS "businessDescription",
            w.value_proposition AS "valueProposition", w.target_market AS "targetMarket",
            w.short_brand_description AS "shortBrandDescription", w.positioning_tags AS "positioningTags",
            w.legal_form AS "legalForm", w.founding_year AS "foundingYear",
            w.employee_count AS "employeeCount", w.annual_revenue_range AS "annualRevenueRange",
            w.business_model_type AS "businessModelType", w.company_stage AS "companyStage",
            w.sales_model AS "salesModel", w.sales_cycle_days AS "salesCycleDays",
            w.primary_icp AS "primaryIcp", w.usp, w.mission, w.vision,
            w.primary_challenges AS "primaryChallenges", w.languages,
            w.regulated_industries AS "regulatedIndustries",
            w.onboarding_step AS "onboardingStep", w.onboarding_completed_at AS "onboardingCompletedAt",
            w.onboarding_file_reupload_required AS "onboardingFileReuploadRequired",
            w.onboarding_files_purged_at AS "onboardingFilesPurgedAt",
            w.created_by AS "createdBy", w.created_at AS "createdAt", w.updated_at AS "updatedAt",
            'owner'::text AS role,
            COALESCE((SELECT plan_key FROM workspace_subscriptions ws2 WHERE ws2.workspace_id = w.id ORDER BY ws2.updated_at DESC LIMIT 1), 'starter') AS "planKey"
     FROM workspaces w
     WHERE w.id = $1 AND w.deleted_at IS NULL
     LIMIT 1`, [workspaceId]);
    return rows[0];
}
const updateColumnMap = {
    companyName: 'name',
    slug: 'slug',
    industry: 'industry',
    companySize: 'company_size',
    countryRegion: 'country_region',
    businessDescription: 'business_description',
    valueProposition: 'value_proposition',
    targetMarket: 'target_market',
    shortBrandDescription: 'short_brand_description',
    positioningTags: 'positioning_tags',
    legalForm: 'legal_form',
    foundingYear: 'founding_year',
    employeeCount: 'employee_count',
    annualRevenueRange: 'annual_revenue_range',
    businessModelType: 'business_model_type',
    companyStage: 'company_stage',
    salesModel: 'sales_model',
    salesCycleDays: 'sales_cycle_days',
    primaryIcp: 'primary_icp',
    usp: 'usp',
    mission: 'mission',
    vision: 'vision',
    primaryChallenges: 'primary_challenges',
    languages: 'languages',
    regulatedIndustries: 'regulated_industries',
};
export async function updateWorkspace(workspaceId, userId, input) {
    const entries = Object.entries(input).filter((entry) => entry[1] !== undefined);
    const values = [workspaceId];
    const assignments = entries.map(([key, value], index) => {
        values.push(value);
        return `${updateColumnMap[key]} = $${index + 2}`;
    });
    await query(`UPDATE workspaces
     SET ${assignments.join(', ')}
     WHERE id = $1 AND deleted_at IS NULL`, values);
    return findWorkspaceForUser(workspaceId, userId);
}
export async function findMembership(workspaceId, userId) {
    const { rows } = await query(`SELECT wm.role
     FROM workspace_members wm
     JOIN workspaces w ON w.id = wm.workspace_id
     WHERE wm.workspace_id = $1 AND wm.user_id = $2 AND w.deleted_at IS NULL
     LIMIT 1`, [workspaceId, userId]);
    return rows[0];
}
//# sourceMappingURL=workspace.repo.js.map