export class BoundedTranslationCache {
    maxEntries;
    ttlMs;
    entries = new Map();
    constructor(maxEntries = 20_000, ttlMs = 24 * 60 * 60 * 1_000) {
        this.maxEntries = maxEntries;
        this.ttlMs = ttlMs;
    }
    get(key) {
        const entry = this.entries.get(key);
        if (!entry)
            return undefined;
        if (entry.expiresAt <= Date.now()) {
            this.entries.delete(key);
            return undefined;
        }
        // Reinserting keeps recently used entries at the end of the Map.
        this.entries.delete(key);
        this.entries.set(key, entry);
        return entry.value;
    }
    set(key, value) {
        this.entries.delete(key);
        this.entries.set(key, { value, expiresAt: Date.now() + this.ttlMs });
        while (this.entries.size > this.maxEntries) {
            const oldestKey = this.entries.keys().next().value;
            if (!oldestKey)
                break;
            this.entries.delete(oldestKey);
        }
    }
}
export const translationCache = new BoundedTranslationCache();
//# sourceMappingURL=translation.cache.js.map