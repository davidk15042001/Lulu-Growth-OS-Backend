export const agentRoles = ['planner', 'analyst', 'strategist', 'executor', 'reviewer'];
export const runStatuses = ['queued', 'planning', 'running', 'waiting_approval', 'completed', 'failed', 'cancelled'];
export const stepStatuses = ['pending', 'running', 'waiting_approval', 'completed', 'failed', 'skipped'];
//# sourceMappingURL=agent.types.js.map