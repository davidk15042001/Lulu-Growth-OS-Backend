import { query } from '../../db/pool.js';
const runSelect = `id, workspace_id AS "workspaceId", created_by AS "createdBy", goal, status, plan,
 result, error_code AS "errorCode", error_message AS "errorMessage", started_at AS "startedAt",
 finished_at AS "finishedAt", created_at AS "createdAt", updated_at AS "updatedAt"`;
const stepSelect = `id, run_id AS "runId", workspace_id AS "workspaceId", sequence_no AS "sequenceNo",
 agent_role AS "agentRole", title, instruction, status, depends_on AS "dependsOn", tool_name AS "toolName",
 tool_input AS "toolInput", tool_output AS "toolOutput", approval_id AS "approvalId", result,
 error_code AS "errorCode", error_message AS "errorMessage", started_at AS "startedAt", finished_at AS "finishedAt",
 created_at AS "createdAt", updated_at AS "updatedAt"`;
const eventSelect = `id, run_id AS "runId", step_id AS "stepId", workspace_id AS "workspaceId",
 event_type AS "eventType", agent_role AS "agentRole", payload, created_at AS "createdAt"`;
export async function createRun(workspaceId, userId, goal) {
    const { rows } = await query(`INSERT INTO agent_runs (workspace_id, created_by, goal)
    VALUES ($1, $2, $3) RETURNING ${runSelect}`, [workspaceId, userId, goal]);
    return rows[0];
}
export async function listAutomatedTargets() {
    const { rows } = await query(`SELECT workspace_id, plan_key, status FROM workspace_subscriptions WHERE status IN ('active', 'trialing') AND plan_key IN ('starter', 'ai', 'test')`);
    return rows;
}
export async function hasRecentAutomaticRun(workspaceId, goal, minutes = 30) {
    const { rows } = await query(`SELECT EXISTS(SELECT 1 FROM agent_runs WHERE workspace_id=$1 AND goal=$2 AND created_at > NOW() - ($3 * INTERVAL '1 minute') AND status IN ('queued','planning','running','waiting_approval','completed')) AS exists`, [workspaceId, goal, minutes]);
    return Boolean(rows[0]?.exists);
}
export async function listRuns(workspaceId, limit = 50) {
    const { rows } = await query(`SELECT ${runSelect} FROM agent_runs WHERE workspace_id=$1 ORDER BY updated_at DESC LIMIT $2`, [workspaceId, limit]);
    return rows;
}
export async function getRun(workspaceId, runId) {
    const { rows } = await query(`SELECT ${runSelect} FROM agent_runs WHERE workspace_id=$1 AND id=$2`, [workspaceId, runId]);
    return rows[0];
}
export async function getLatestCompletedInitialAnalysis(workspaceId) {
    const { rows } = await query(`SELECT ${runSelect}
     FROM agent_runs
     WHERE workspace_id=$1
       AND goal='[initial-business-analysis] Detailed post-onboarding business intelligence analysis'
       AND status='completed'
     ORDER BY finished_at DESC NULLS LAST, updated_at DESC
     LIMIT 1`, [workspaceId]);
    return rows[0];
}
export async function updateRun(runId, patch) {
    const keys = Object.keys(patch);
    const values = keys.map((key) => patch[key]);
    const assignments = keys.map((key, index) => `${key}=$${index + 2}`).join(', ');
    const { rows } = await query(`UPDATE agent_runs SET ${assignments}, updated_at=NOW() WHERE id=$1 RETURNING ${runSelect}`, [runId, ...values]);
    return rows[0];
}
export async function createSteps(steps) {
    const created = [];
    for (const step of steps) {
        const { rows } = await query(`INSERT INTO agent_run_steps (run_id, workspace_id, sequence_no, agent_role, title, instruction, tool_name, tool_input)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING ${stepSelect}`, [step.runId, step.workspaceId, step.sequenceNo, step.agentRole, step.title, step.instruction, step.toolName ?? null, step.toolInput ?? null]);
        if (rows[0])
            created.push(rows[0]);
    }
    return created;
}
export async function listSteps(workspaceId, runId) {
    const { rows } = await query(`SELECT ${stepSelect} FROM agent_run_steps WHERE workspace_id=$1 AND run_id=$2 ORDER BY sequence_no ASC`, [workspaceId, runId]);
    return rows;
}
export async function getStep(workspaceId, runId, stepId) {
    const { rows } = await query(`SELECT ${stepSelect} FROM agent_run_steps WHERE workspace_id=$1 AND run_id=$2 AND id=$3`, [workspaceId, runId, stepId]);
    return rows[0];
}
export async function updateStep(stepId, patch) {
    const keys = Object.keys(patch);
    const values = keys.map((key) => patch[key]);
    const assignments = keys.map((key, index) => `${key}=$${index + 2}`).join(', ');
    const { rows } = await query(`UPDATE agent_run_steps SET ${assignments}, updated_at=NOW() WHERE id=$1 RETURNING ${stepSelect}`, [stepId, ...values]);
    return rows[0];
}
export async function addEvent(input) {
    const { rows } = await query(`INSERT INTO agent_run_events (run_id, step_id, workspace_id, event_type, agent_role, payload)
    VALUES ($1,$2,$3,$4,$5,$6) RETURNING ${eventSelect}`, [input.runId, input.stepId ?? null, input.workspaceId, input.eventType, input.agentRole ?? null, input.payload ?? {}]);
    return rows[0];
}
export async function getWorkspacePlan(workspaceId) {
    const { rows } = await query(`SELECT plan_key, status FROM workspace_subscriptions WHERE workspace_id=$1 ORDER BY updated_at DESC LIMIT 1`, [workspaceId]);
    return rows[0] ?? { plan_key: 'explorer', status: 'inactive' };
}
export async function getApprovalStatus(workspaceId, approvalId) {
    const { rows } = await query(`SELECT status FROM approval_requests WHERE workspace_id=$1 AND id=$2`, [workspaceId, approvalId]);
    return rows[0]?.status ?? null;
}
export async function listEvents(workspaceId, runId) {
    const { rows } = await query(`SELECT ${eventSelect} FROM agent_run_events WHERE workspace_id=$1 AND run_id=$2 ORDER BY created_at ASC`, [workspaceId, runId]);
    return rows;
}
export async function createKnowledgeSnapshot(input) {
    const { rows } = await query(`
    INSERT INTO workspace_knowledge_snapshots
      (workspace_id, source_run_id, status, confidence, executive_summary, data_gaps,
       verified_facts, priorities, knowledge_base, source_manifest, generated_at)
    VALUES ($1,$2,$3,$4,$5,$6::jsonb,$7::jsonb,$8::jsonb,$9::jsonb,$10::jsonb,$11)
    ON CONFLICT (workspace_id, snapshot_type, source_run_id)
    DO UPDATE SET status=EXCLUDED.status, confidence=EXCLUDED.confidence,
      executive_summary=EXCLUDED.executive_summary, data_gaps=EXCLUDED.data_gaps,
      verified_facts=EXCLUDED.verified_facts, priorities=EXCLUDED.priorities,
      knowledge_base=EXCLUDED.knowledge_base, source_manifest=EXCLUDED.source_manifest,
      generated_at=EXCLUDED.generated_at, updated_at=NOW()
    RETURNING id, workspace_id AS "workspaceId", source_run_id AS "sourceRunId", status,
      confidence, executive_summary AS "executiveSummary", data_gaps AS "dataGaps",
      verified_facts AS "verifiedFacts", priorities, knowledge_base AS "knowledgeBase",
      source_manifest AS "sourceManifest", generated_at AS "generatedAt", updated_at AS "updatedAt"`, [input.workspaceId, input.sourceRunId, input.status, input.confidence ?? null, input.executiveSummary ?? null,
        JSON.stringify(input.dataGaps ?? []), JSON.stringify(input.verifiedFacts ?? []), JSON.stringify(input.priorities ?? []),
        JSON.stringify(input.knowledgeBase ?? {}), JSON.stringify(input.sourceManifest ?? {}), input.generatedAt ?? null]);
    return rows[0];
}
export async function replaceKnowledgeSections(snapshotId, workspaceId, sections) {
    for (const [sectionKey, content] of Object.entries(sections)) {
        if (!content || typeof content !== 'object')
            continue;
        await query(`
      INSERT INTO workspace_knowledge_sections (snapshot_id, workspace_id, section_key, status, content)
      VALUES ($1,$2,$3,$4,$5::jsonb)
      ON CONFLICT (snapshot_id, section_key)
      DO UPDATE SET status=EXCLUDED.status, content=EXCLUDED.content, updated_at=NOW()`, [snapshotId, workspaceId, sectionKey, 'completed', JSON.stringify(content)]);
    }
}
export async function replaceIntelligenceMetrics(input) {
    for (const [metricKey, raw] of Object.entries(input.metrics)) {
        const metric = raw && typeof raw === 'object' ? raw : {};
        const status = typeof metric.sourceStatus === 'string' ? metric.sourceStatus : 'unavailable';
        const safeStatus = ['verified', 'derived', 'forecast', 'unavailable', 'not_applicable'].includes(status) ? status : 'unavailable';
        await query(`
      INSERT INTO workspace_intelligence_metrics
        (workspace_id, snapshot_id, metric_key, value, unit, period, source, source_status,
         confidence, limitations, measured_at)
      VALUES ($1,$2,$3,$4::jsonb,$5,$6,$7,$8,$9,$10::jsonb,$11)
      ON CONFLICT (workspace_id, snapshot_id, metric_key)
      DO UPDATE SET value=EXCLUDED.value, unit=EXCLUDED.unit, period=EXCLUDED.period,
        source=EXCLUDED.source, source_status=EXCLUDED.source_status, confidence=EXCLUDED.confidence,
        limitations=EXCLUDED.limitations, measured_at=EXCLUDED.measured_at, updated_at=NOW()`, [input.workspaceId, input.snapshotId, metricKey, JSON.stringify(metric.value ?? null),
            typeof metric.unit === 'string' ? metric.unit : null, typeof metric.period === 'string' ? metric.period : null,
            typeof metric.source === 'string' ? metric.source : null, safeStatus,
            typeof metric.confidence === 'string' ? metric.confidence : null,
            JSON.stringify(Array.isArray(metric.limitations) ? metric.limitations : []), null]);
    }
}
export async function getLatestKnowledgeSnapshot(workspaceId) {
    const { rows } = await query(`
    SELECT id, workspace_id AS "workspaceId", source_run_id AS "sourceRunId", snapshot_type AS "snapshotType",
      status, confidence, executive_summary AS "executiveSummary", data_gaps AS "dataGaps",
      verified_facts AS "verifiedFacts", priorities, knowledge_base AS "knowledgeBase",
      source_manifest AS "sourceManifest", generated_at AS "generatedAt", updated_at AS "updatedAt"
    FROM workspace_knowledge_snapshots
    WHERE workspace_id=$1 AND snapshot_type='initial_business_analysis' AND status='completed'
    ORDER BY generated_at DESC NULLS LAST, updated_at DESC LIMIT 1`, [workspaceId]);
    return rows[0] ?? null;
}
export async function listKnowledgeSections(workspaceId, snapshotId) {
    const { rows } = await query(`SELECT section_key AS "sectionKey", status, content, updated_at AS "updatedAt"
    FROM workspace_knowledge_sections WHERE workspace_id=$1 AND snapshot_id=$2 ORDER BY section_key`, [workspaceId, snapshotId]);
    return rows;
}
export async function listIntelligenceMetrics(workspaceId, snapshotId) {
    const values = [workspaceId];
    const where = snapshotId ? 'AND snapshot_id=$2' : '';
    if (snapshotId)
        values.push(snapshotId);
    const { rows } = await query(`SELECT metric_key AS "metricKey", value, unit, period, source,
      source_status AS "sourceStatus", confidence, limitations, measured_at AS "measuredAt", updated_at AS "updatedAt"
    FROM workspace_intelligence_metrics WHERE workspace_id=$1 ${where} ORDER BY metric_key`, values);
    return rows;
}
export async function getKnowledgeBundle(workspaceId) {
    const snapshot = await getLatestKnowledgeSnapshot(workspaceId);
    if (!snapshot)
        return null;
    const [sections, metrics] = await Promise.all([
        listKnowledgeSections(workspaceId, snapshot.id),
        listIntelligenceMetrics(workspaceId, snapshot.id),
    ]);
    return { snapshot, sections, metrics };
}
//# sourceMappingURL=agent.repo.js.map