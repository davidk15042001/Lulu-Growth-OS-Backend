import { createdResponse, successResponse } from '../../utils/response.js';
import * as service from './agent.service.js';
import { agentRunParamsSchema, agentStepDecisionSchema, createAgentRunSchema } from './agent.validator.js';
export async function create(req, res, next) {
    try {
        const params = agentRunParamsSchema.parse(req.params);
        const input = createAgentRunSchema.parse(req.body);
        return createdResponse(res, 'Agent run started', await service.startRun(params.workspaceId, req.user.id, input.goal, input.module));
    }
    catch (error) {
        next(error);
    }
}
export async function knowledge(req, res, next) {
    try {
        const params = agentRunParamsSchema.parse(req.params);
        const bundle = await service.getKnowledgeBundle(params.workspaceId);
        return successResponse(res, 'Workspace intelligence loaded', bundle ?? { snapshot: null, sections: [], metrics: [] });
    }
    catch (error) {
        next(error);
    }
}
export async function list(req, res, next) {
    try {
        const params = agentRunParamsSchema.parse(req.params);
        return successResponse(res, 'Agent runs loaded', { items: await service.listRuns(params.workspaceId) });
    }
    catch (error) {
        next(error);
    }
}
export async function detail(req, res, next) {
    try {
        const params = agentRunParamsSchema.parse(req.params);
        return successResponse(res, 'Agent run loaded', await service.getRunDetails(params.workspaceId, params.runId));
    }
    catch (error) {
        next(error);
    }
}
export async function cancel(req, res, next) {
    try {
        const params = agentRunParamsSchema.parse(req.params);
        return successResponse(res, 'Agent run cancelled', await service.cancelRun(params.workspaceId, params.runId));
    }
    catch (error) {
        next(error);
    }
}
export async function approve(req, res, next) {
    try {
        const params = agentRunParamsSchema.extend({ stepId: agentRunParamsSchema.shape.runId }).parse(req.params);
        const decision = agentStepDecisionSchema.parse(req.body);
        return successResponse(res, 'Agent step decision recorded', await service.approveStep(params.workspaceId, params.runId, params.stepId, req.user.id, decision));
    }
    catch (error) {
        next(error);
    }
}
//# sourceMappingURL=agent.controller.js.map