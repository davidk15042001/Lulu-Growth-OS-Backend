const exceptionModules = new Set(['seo', 'geo', 'aeo', 'website']);
export function getAgentCapabilities(plan, module) {
    if (plan === 'explorer' || plan === 'viewer')
        return { analyze: false, recommend: false, act: false, autonomous: false, automatic: false };
    if (plan === 'ai' || plan === 'test')
        return { analyze: true, recommend: true, act: true, autonomous: true, automatic: true };
    const exception = exceptionModules.has(module);
    return { analyze: true, recommend: exception, act: exception, autonomous: exception, automatic: true };
}
export function isAgentModule(value) {
    return value === 'general' || value === 'seo' || value === 'geo' || value === 'aeo' || value === 'website';
}
//# sourceMappingURL=agent.capabilities.js.map