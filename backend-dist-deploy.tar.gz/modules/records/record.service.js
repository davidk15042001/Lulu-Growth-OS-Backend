import { conflictError, notFoundError } from '../../utils/app-error.js';
import * as repo from './record.repo.js';
export function listRecords(workspaceId, resourceType, filters) {
    return repo.listRecords(workspaceId, resourceType, filters);
}
export async function getRecord(workspaceId, resourceType, recordId) {
    const record = await repo.findRecord(workspaceId, resourceType, recordId);
    if (!record)
        throw notFoundError('Record not found');
    return record;
}
export function createRecord(workspaceId, resourceType, userId, input) {
    return repo.createRecord(workspaceId, resourceType, userId, input);
}
export async function updateRecord(workspaceId, resourceType, recordId, userId, input) {
    const result = await repo.updateRecord(workspaceId, resourceType, recordId, userId, input);
    if (result.status === 'not_found')
        throw notFoundError('Record not found');
    if (result.status === 'version_conflict') {
        throw conflictError(`Record changed since version ${input.expectedVersion}`);
    }
    return result.record;
}
export async function archiveRecord(workspaceId, resourceType, recordId, userId) {
    if (!(await repo.archiveRecord(workspaceId, resourceType, recordId, userId))) {
        throw notFoundError('Record not found');
    }
}
export async function restoreRecord(workspaceId, resourceType, recordId, userId) {
    const record = await repo.restoreRecord(workspaceId, resourceType, recordId, userId);
    if (!record)
        throw notFoundError('Archived record not found');
    return record;
}
//# sourceMappingURL=record.service.js.map