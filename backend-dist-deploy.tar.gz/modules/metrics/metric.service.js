import { conflictError, notFoundError } from '../../utils/app-error.js';
import * as repo from './metric.repo.js';
export const listMetrics = repo.listMetrics;
export async function getMetric(workspaceId, metricId) {
    const metric = await repo.findMetric(workspaceId, metricId);
    if (!metric)
        throw notFoundError('Metric not found');
    return metric;
}
export async function createMetric(workspaceId, input) {
    try {
        const metricId = await repo.createMetric(workspaceId, input);
        if (!metricId)
            throw new Error('Metric insert did not return an id');
        return getMetric(workspaceId, metricId);
    }
    catch (error) {
        if (error.code === '23505') {
            throw conflictError('A metric with this key already exists');
        }
        throw error;
    }
}
export async function updateMetric(workspaceId, metricId, input) {
    try {
        if (!(await repo.updateMetric(workspaceId, metricId, input))) {
            throw notFoundError('Metric not found');
        }
        return getMetric(workspaceId, metricId);
    }
    catch (error) {
        if (error.code === '23505') {
            throw conflictError('A metric with this key already exists');
        }
        throw error;
    }
}
export async function archiveMetric(workspaceId, metricId) {
    if (!(await repo.archiveMetric(workspaceId, metricId))) {
        throw notFoundError('Metric not found');
    }
}
export async function insertPoints(workspaceId, metricId, points) {
    const inserted = await repo.insertPoints(workspaceId, metricId, points);
    if (inserted === undefined)
        throw notFoundError('Metric not found');
    return { inserted };
}
export const listPoints = (workspaceId, metricId, filters) => repo.listPoints(workspaceId, metricId, filters);
//# sourceMappingURL=metric.service.js.map