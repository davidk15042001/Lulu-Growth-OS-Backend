import { query, withTransaction } from '../../db/pool.js';
import { buildUpdateSet } from '../../db/update-builder.js';
const metricSelect = `
  md.id,
  md.workspace_id AS "workspaceId",
  md.key,
  md.name,
  md.domain,
  md.unit,
  md.format,
  md.source,
  md.configuration,
  latest.value AS "latestValue",
  latest.recorded_at AS "latestRecordedAt",
  md.created_at AS "createdAt",
  md.updated_at AS "updatedAt"
`;
const metricFrom = `
  FROM metric_definitions md
  LEFT JOIN LATERAL (
    SELECT mp.value, mp.recorded_at
    FROM metric_points mp
    WHERE mp.metric_id = md.id
    ORDER BY mp.recorded_at DESC
    LIMIT 1
  ) latest ON TRUE
`;
export async function listMetrics(workspaceId) {
    const { rows } = await query(`SELECT ${metricSelect}
     ${metricFrom}
     WHERE md.workspace_id = $1 AND md.deleted_at IS NULL
     ORDER BY md.domain, md.name`, [workspaceId]);
    return rows;
}
export async function findMetric(workspaceId, metricId) {
    const { rows } = await query(`SELECT ${metricSelect}
     ${metricFrom}
     WHERE md.workspace_id = $1 AND md.id = $2 AND md.deleted_at IS NULL
     LIMIT 1`, [workspaceId, metricId]);
    return rows[0];
}
export async function createMetric(workspaceId, input) {
    const { rows } = await query(`INSERT INTO metric_definitions (
       workspace_id, key, name, domain, unit, format, source, configuration
     ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
     RETURNING id`, [
        workspaceId,
        input.key,
        input.name,
        input.domain,
        input.unit ?? 'number',
        input.format ?? null,
        input.source ?? null,
        input.configuration ?? {},
    ]);
    return rows[0]?.id;
}
const updateColumns = {
    key: 'key',
    name: 'name',
    domain: 'domain',
    unit: 'unit',
    format: 'format',
    source: 'source',
    configuration: 'configuration',
};
export async function updateMetric(workspaceId, metricId, input) {
    const update = buildUpdateSet(input, updateColumns, 2);
    const { rowCount } = await query(`UPDATE metric_definitions
     SET ${update.assignments.join(', ')}
     WHERE workspace_id = $1 AND id = $2 AND deleted_at IS NULL`, [workspaceId, metricId, ...update.values]);
    return rowCount > 0;
}
export async function archiveMetric(workspaceId, metricId) {
    const { rowCount } = await query(`UPDATE metric_definitions
     SET deleted_at = NOW()
     WHERE workspace_id = $1 AND id = $2 AND deleted_at IS NULL`, [workspaceId, metricId]);
    return rowCount > 0;
}
export async function insertPoints(workspaceId, metricId, points) {
    return withTransaction(async (client) => {
        const metric = await query(`SELECT id FROM metric_definitions
       WHERE workspace_id = $1 AND id = $2 AND deleted_at IS NULL
       LIMIT 1`, [workspaceId, metricId], client);
        if (!metric.rows[0])
            return undefined;
        const values = [];
        const placeholders = points.map((point, index) => {
            const offset = index * 5;
            values.push(metricId, point.recordedAt, point.value, point.dimensions ?? {}, point.sourceRecordId ?? null);
            return `($${offset + 1}, $${offset + 2}, $${offset + 3}, $${offset + 4}, $${offset + 5})`;
        });
        const result = await query(`INSERT INTO metric_points (metric_id, recorded_at, value, dimensions, source_record_id)
       VALUES ${placeholders.join(', ')}`, values, client);
        return result.rowCount;
    });
}
export async function listPoints(workspaceId, metricId, filters) {
    const values = [workspaceId, metricId];
    const conditions = [
        'md.workspace_id = $1',
        'md.id = $2',
        'md.deleted_at IS NULL',
    ];
    if (filters.from) {
        values.push(filters.from);
        conditions.push(`mp.recorded_at >= $${values.length}`);
    }
    if (filters.to) {
        values.push(filters.to);
        conditions.push(`mp.recorded_at <= $${values.length}`);
    }
    const offset = (filters.page - 1) * filters.limit;
    const order = filters.order === 'desc' ? 'DESC' : 'ASC';
    const where = conditions.join(' AND ');
    const [items, count] = await Promise.all([
        query(`SELECT
         mp.id::text AS id,
         mp.recorded_at AS "recordedAt",
         mp.value,
         mp.dimensions,
         mp.source_record_id AS "sourceRecordId"
       FROM metric_points mp
       JOIN metric_definitions md ON md.id = mp.metric_id
       WHERE ${where}
       ORDER BY mp.recorded_at ${order}, mp.id ${order}
       LIMIT $${values.length + 1} OFFSET $${values.length + 2}`, [...values, filters.limit, offset]),
        query(`SELECT count(*)::text AS total
       FROM metric_points mp
       JOIN metric_definitions md ON md.id = mp.metric_id
       WHERE ${where}`, values),
    ]);
    const total = Number.parseInt(count.rows[0]?.total ?? '0', 10);
    return {
        items: items.rows,
        pagination: {
            page: filters.page,
            limit: filters.limit,
            total,
            pages: Math.ceil(total / filters.limit),
        },
    };
}
//# sourceMappingURL=metric.repo.js.map