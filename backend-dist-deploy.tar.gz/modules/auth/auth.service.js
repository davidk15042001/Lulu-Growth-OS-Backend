import bcrypt from 'bcryptjs';
import { signToken } from '../../utils/jwt.js';
import { sendOtpEmail, sendResetEmail } from '../../utils/mailer.js';
import { logger } from '../../config/logger.js';
import * as repo from './auth.repo.js';
import { env } from '../../config/env.js';
export async function registerUser(email, password, firstName, lastName) {
    const existingUser = await repo.getUserByEmail(email);
    if (existingUser)
        return { conflict: true };
    const passwordHash = await bcrypt.hash(password, env.BCRYPT_ROUNDS);
    const user = await repo.createUser(email, passwordHash, firstName, lastName);
    if (!user)
        throw new Error('Failed to create user');
    await repo.verifyUser(user.id);
    logger.info({ email }, 'User registered and activated without verification email');
    return { ok: true, userId: user.id };
}
export async function verifyEmailOtp(email, code) {
    const user = await repo.getUserByEmail(email);
    if (!user)
        return { notFound: true };
    const otps = await repo.getUnusedOtpsForUser(user.id, 'verify_email');
    for (const otp of otps) {
        const ok = await bcrypt.compare(code, otp.otp_hash);
        if (ok) {
            await repo.markOtpAsUsed(otp.id);
            await repo.verifyUser(user.id);
            logger.info({ email }, 'Email OTP verified');
            return { ok: true };
        }
        else {
            await repo.incrementOtpAttempts(otp.id);
        }
    }
    return { invalid: true };
}
export async function loginUser(email, password, options) {
    const user = await repo.getUserByEmail(email);
    if (!user)
        return { invalid: true };
    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok)
        return { invalid: true };
    // Registration no longer requires email OTP. Legacy accounts that were
    // created before that change are activated after a successful password
    // check, so they do not get trapped in the retired verification flow.
    if (!user.verified_at) {
        await repo.verifyUser(user.id);
    }
    const session = await repo.createSingleDeviceSession(user.id, {
        userAgent: options?.userAgent ?? null,
        ipAddress: options?.ipAddress ?? null,
    });
    const token = signToken({ sub: user.id, email, tv: session.tokenVersion });
    const refreshToken = session.token;
    return {
        ok: true,
        token,
        refreshToken,
        user: {
            id: user.id,
            email,
            firstName: user.first_name,
            lastName: user.last_name,
            role: user.role
        }
    };
}
export async function refreshAccessToken(rawToken, options) {
    const parts = String(rawToken).split('.');
    if (parts.length !== 2)
        return { invalid: true };
    const [selector, validator] = parts;
    if (!selector || !validator)
        return { invalid: true };
    const rotated = await repo.rotateRefreshToken(selector, validator, {
        userAgent: options?.userAgent ?? null,
        ipAddress: options?.ipAddress ?? null,
    });
    if (rotated.status === 'invalid')
        return { invalid: true };
    if (rotated.status === 'expired')
        return { expired: true };
    const user = await repo.getUserById(rotated.userId);
    if (!user)
        return { invalid: true };
    const token = signToken({ sub: user.id, email: user.email, tv: user.token_version });
    return {
        ok: true,
        token,
        refreshToken: rotated.refreshToken,
        user: {
            id: user.id,
            email: user.email,
            firstName: user.first_name,
            lastName: user.last_name,
            role: user.role
        }
    };
}
export async function logout(rawToken) {
    if (!rawToken)
        return;
    const parts = String(rawToken).split('.');
    if (parts.length === 2 && parts[0]) {
        await repo.revokeRefreshTokenBySelector(parts[0]);
    }
}
export async function logoutAll(userId) {
    await repo.revokeAllRefreshTokensForUser(userId);
    await repo.incrementTokenVersion(userId);
}
export async function resendOtp(email, purpose) {
    const user = await repo.getUserByEmail(email);
    if (!user)
        return { ok: true };
    if (purpose === 'verify' && user.verified_at)
        return { alreadyVerified: true };
    const code = await repo.issueOtp(user.id, purpose === 'verify' ? 'verify_email' : 'password_reset', null);
    if (purpose === 'verify') {
        await sendOtpEmail(email, code);
    }
    else {
        await sendResetEmail(email, code);
    }
    logger.info({ email, purpose }, `${purpose === 'verify' ? 'Verification' : 'Password reset'} OTP re-sent`);
    return { ok: true };
}
export async function createPasswordResetOtp(email) {
    const user = await repo.getUserByEmail(email);
    if (!user)
        return;
    const code = await repo.issueOtp(user.id, 'password_reset', null);
    await sendResetEmail(email, code);
    logger.info({ email }, 'Password reset OTP generated');
}
export async function resetPasswordWithOtp(email, code, password) {
    const user = await repo.getUserByEmail(email);
    if (!user)
        return { invalid: true };
    const otps = await repo.getUnusedOtpsForUser(user.id, 'password_reset');
    for (const otp of otps) {
        const ok = await bcrypt.compare(code, otp.otp_hash);
        if (ok) {
            await repo.markOtpAsUsed(otp.id);
            const hash = await bcrypt.hash(password, env.BCRYPT_ROUNDS);
            await repo.resetPasswordAndRevokeSessions(user.id, hash);
            logger.info({ email }, 'Password reset with OTP');
            return { ok: true };
        }
        else {
            await repo.incrementOtpAttempts(otp.id);
        }
    }
    return { invalid: true };
}
export async function getCurrentUser(userId) {
    return repo.getUserById(userId);
}
export async function updateCurrentUser(userId, input) {
    return repo.updateUserProfile(userId, input);
}
//# sourceMappingURL=auth.service.js.map