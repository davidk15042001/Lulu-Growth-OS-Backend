import { env, isProd } from '../../config/env.js';
import * as service from './auth.service.js';
import { jsonError } from '../../utils/response.js';
import { registerSchema, verifyOtpSchema, loginSchema, refreshSchema, forgotPasswordSchema, resetPasswordSchema, resendOtpSchema, updateProfileSchema, } from './auth.validator.js';
const RT_COOKIE_NAME = 'rt';
const refreshCookieSameSite = env.REFRESH_COOKIE_SAME_SITE ?? (isProd ? 'none' : 'lax');
const RT_COOKIE_OPTS = {
    httpOnly: true,
    sameSite: refreshCookieSameSite,
    secure: isProd,
    maxAge: env.REFRESH_TOKEN_TTL_DAYS * 24 * 60 * 60 * 1000,
    path: '/'
};
export async function register(req, res, next) {
    try {
        const body = registerSchema.parse(req.body);
        const result = await service.registerUser(body.email, body.password, body.first_name, body.last_name);
        if ('conflict' in result) {
            return jsonError(res, 409, 'EMAIL_IN_USE', 'Email already in use');
        }
        return res.status(201).json({ success: true, message: 'Registered. You can sign in now.' });
    }
    catch (e) {
        next(e);
    }
}
export async function verifyOtp(req, res, next) {
    try {
        const body = verifyOtpSchema.parse(req.body);
        const result = await service.verifyEmailOtp(body.email, body.code);
        if ('notFound' in result)
            return jsonError(res, 404, 'ACCOUNT_NOT_FOUND', 'Account not found');
        if ('invalid' in result)
            return jsonError(res, 400, 'INVALID_OTP', 'Invalid verification code');
        if ('used' in result)
            return jsonError(res, 400, 'OTP_USED', 'Code already used');
        if ('expired' in result)
            return jsonError(res, 400, 'OTP_EXPIRED', 'Verification code expired');
        return res.json({ success: true, message: 'Account verified' });
    }
    catch (e) {
        next(e);
    }
}
export async function login(req, res, next) {
    try {
        const body = loginSchema.parse(req.body);
        const userAgent = typeof req.headers['user-agent'] === 'string' ? req.headers['user-agent'] : null;
        const result = await service.loginUser(body.email, body.password, { userAgent, ipAddress: req.ip ?? null });
        if ('invalid' in result)
            return jsonError(res, 401, 'INVALID_CREDENTIALS', 'Invalid email or password');
        if ('unverified' in result)
            return jsonError(res, 403, 'ACCOUNT_UNVERIFIED', 'Verify your email to continue');
        res.cookie(RT_COOKIE_NAME, result.refreshToken, RT_COOKIE_OPTS);
        return res.json({
            success: true,
            message: 'Logged in',
            data: {
                token: result.token,
                user: result.user
            }
        });
    }
    catch (e) {
        next(e);
    }
}
export async function refresh(req, res, next) {
    try {
        const body = refreshSchema.parse(req.body);
        const refreshToken = body.refresh_token || req.cookies?.[RT_COOKIE_NAME];
        if (!refreshToken)
            return jsonError(res, 401, 'MISSING_REFRESH_TOKEN', 'Please sign in');
        const userAgent = typeof req.headers['user-agent'] === 'string' ? req.headers['user-agent'] : null;
        const result = await service.refreshAccessToken(refreshToken, { userAgent, ipAddress: req.ip ?? null });
        if ('invalid' in result)
            return jsonError(res, 401, 'INVALID_REFRESH_TOKEN', 'Please sign in');
        if ('expired' in result)
            return jsonError(res, 401, 'REFRESH_TOKEN_EXPIRED', 'Please sign in');
        res.cookie(RT_COOKIE_NAME, result.refreshToken, RT_COOKIE_OPTS);
        return res.json({
            success: true,
            message: 'Token refreshed',
            data: {
                token: result.token,
                user: result.user
            }
        });
    }
    catch (e) {
        next(e);
    }
}
export async function logout(req, res, next) {
    try {
        const refreshToken = req.cookies?.[RT_COOKIE_NAME];
        await service.logout(refreshToken);
        res.clearCookie(RT_COOKIE_NAME, RT_COOKIE_OPTS);
        return res.json({ success: true, message: 'Logged out' });
    }
    catch (e) {
        next(e);
    }
}
export async function logoutAll(req, res, next) {
    try {
        const userId = req.user?.id;
        if (!userId)
            return jsonError(res, 401, 'UNAUTHORIZED', 'Please sign in');
        await service.logoutAll(userId);
        res.clearCookie(RT_COOKIE_NAME, RT_COOKIE_OPTS);
        return res.json({ success: true, message: 'Logged out from all devices' });
    }
    catch (e) {
        next(e);
    }
}
export async function forgotPassword(req, res, next) {
    try {
        const body = forgotPasswordSchema.parse(req.body);
        await service.createPasswordResetOtp(body.email);
        return res.json({ success: true, message: 'If the email exists, a reset code has been sent' });
    }
    catch (e) {
        next(e);
    }
}
export async function resendOtp(req, res, next) {
    try {
        const body = resendOtpSchema.parse(req.body);
        const result = await service.resendOtp(body.email, body.purpose);
        if ('alreadyVerified' in result)
            return res.json({ success: true, message: 'Account already verified' });
        return res.json({ success: true, message: 'OTP re-sent if account exists' });
    }
    catch (e) {
        next(e);
    }
}
export async function resetPassword(req, res, next) {
    try {
        const body = resetPasswordSchema.parse(req.body);
        const result = await service.resetPasswordWithOtp(body.email, body.code, body.password);
        if ('invalid' in result)
            return jsonError(res, 400, 'INVALID_RESET_CODE', 'Invalid reset code');
        if ('expired' in result)
            return jsonError(res, 400, 'RESET_CODE_EXPIRED', 'Reset code expired');
        return res.json({ success: true, message: 'Password updated' });
    }
    catch (e) {
        next(e);
    }
}
export async function me(req, res, next) {
    try {
        const user = await service.getCurrentUser(req.user.id);
        if (!user)
            return res.status(404).json({ success: false, error: { code: 'NOT_FOUND', message: 'User not found' } });
        return res.json({
            success: true,
            data: {
                id: user.id,
                email: user.email,
                firstName: user.first_name,
                lastName: user.last_name,
                role: user.role,
            },
        });
    }
    catch (error) {
        next(error);
    }
}
export async function updateMe(req, res, next) {
    try {
        const input = updateProfileSchema.parse(req.body);
        const user = await service.updateCurrentUser(req.user.id, input);
        return res.json({
            success: true,
            message: 'Profile updated',
            data: user ? {
                id: user.id,
                email: user.email,
                firstName: user.first_name,
                lastName: user.last_name,
                role: user.role,
            } : null,
        });
    }
    catch (error) {
        next(error);
    }
}
//# sourceMappingURL=auth.controller.js.map