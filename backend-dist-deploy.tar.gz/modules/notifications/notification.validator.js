import { z } from 'zod';
export const notificationParamsSchema = z.object({
    workspaceId: z.string().uuid(),
    notificationId: z.string().uuid().optional(),
});
export const listNotificationsQuerySchema = z.object({
    page: z.coerce.number().int().min(1).default(1),
    limit: z.coerce.number().int().min(1).max(100).default(25),
    unreadOnly: z.enum(['true', 'false']).transform((value) => value === 'true').default(false),
    severity: z.enum(['info', 'success', 'warning', 'critical']).optional(),
});
//# sourceMappingURL=notification.validator.js.map