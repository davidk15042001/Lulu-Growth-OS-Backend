import { query } from '../../db/pool.js';
const notificationSelect = `
  id,
  workspace_id AS "workspaceId",
  notification_type AS "notificationType",
  severity,
  title,
  body,
  entity_type AS "entityType",
  entity_id AS "entityId",
  data,
  read_at AS "readAt",
  created_at AS "createdAt"
`;
export async function createNotification(input) {
    const { rows } = await query(`INSERT INTO notifications (
       workspace_id, user_id, notification_type, severity, title, body,
       entity_type, entity_id, data
     ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
     RETURNING ${notificationSelect}`, [
        input.workspaceId,
        input.userId,
        input.notificationType,
        input.severity ?? 'info',
        input.title,
        input.body ?? null,
        input.entityType ?? null,
        input.entityId ?? null,
        input.data ?? {},
    ]);
    return rows[0];
}
export async function listNotifications(workspaceId, userId, filters) {
    const values = [workspaceId, userId];
    const conditions = ['workspace_id = $1', 'user_id = $2', 'dismissed_at IS NULL'];
    if (filters.unreadOnly)
        conditions.push('read_at IS NULL');
    if (filters.severity) {
        values.push(filters.severity);
        conditions.push(`severity = $${values.length}`);
    }
    const where = conditions.join(' AND ');
    const offset = (filters.page - 1) * filters.limit;
    const [items, count, unread] = await Promise.all([
        query(`SELECT ${notificationSelect}
       FROM notifications
       WHERE ${where}
       ORDER BY created_at DESC, id DESC
       LIMIT $${values.length + 1} OFFSET $${values.length + 2}`, [...values, filters.limit, offset]),
        query(`SELECT count(*)::text AS total FROM notifications WHERE ${where}`, values),
        query(`SELECT count(*)::text AS total
       FROM notifications
       WHERE workspace_id = $1 AND user_id = $2 AND read_at IS NULL AND dismissed_at IS NULL`, [workspaceId, userId]),
    ]);
    const total = Number.parseInt(count.rows[0]?.total ?? '0', 10);
    return {
        items: items.rows,
        unread: Number.parseInt(unread.rows[0]?.total ?? '0', 10),
        pagination: {
            page: filters.page,
            limit: filters.limit,
            total,
            pages: Math.ceil(total / filters.limit),
        },
    };
}
export async function markRead(workspaceId, userId, notificationId) {
    const { rows } = await query(`UPDATE notifications
     SET read_at = COALESCE(read_at, NOW())
     WHERE workspace_id = $1 AND user_id = $2 AND id = $3 AND dismissed_at IS NULL
     RETURNING ${notificationSelect}`, [workspaceId, userId, notificationId]);
    return rows[0];
}
export async function markAllRead(workspaceId, userId) {
    const { rowCount } = await query(`UPDATE notifications
     SET read_at = NOW()
     WHERE workspace_id = $1 AND user_id = $2 AND read_at IS NULL AND dismissed_at IS NULL`, [workspaceId, userId]);
    return rowCount;
}
export async function dismiss(workspaceId, userId, notificationId) {
    const { rowCount } = await query(`UPDATE notifications
     SET dismissed_at = NOW()
     WHERE workspace_id = $1 AND user_id = $2 AND id = $3 AND dismissed_at IS NULL`, [workspaceId, userId, notificationId]);
    return rowCount > 0;
}
//# sourceMappingURL=notification.repo.js.map