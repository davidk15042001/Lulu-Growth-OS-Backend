import { query } from '../../db/pool.js';
import * as recordRepo from '../records/record.repo.js';
const recordSelect = `
  id,
  workspace_id AS "workspaceId",
  resource_type AS "resourceType",
  name,
  description,
  status,
  stage,
  external_id AS "externalId",
  data,
  updated_at AS "updatedAt",
  created_at AS "createdAt"
`;
export async function listChannelRecords(workspaceId, resourceType, limit = 100) {
    const { rows } = await query(`SELECT ${recordSelect}
     FROM workspace_records
     WHERE workspace_id = $1
       AND resource_type = $2
       AND deleted_at IS NULL
     ORDER BY updated_at DESC, created_at DESC
     LIMIT $3`, [workspaceId, resourceType, limit]);
    return rows;
}
export async function findRecordByExternalId(workspaceId, resourceType, externalId) {
    const { rows } = await query(`SELECT id
     FROM workspace_records
     WHERE workspace_id = $1
       AND resource_type = $2
       AND external_id = $3
       AND deleted_at IS NULL
     LIMIT 1`, [workspaceId, resourceType, externalId]);
    return rows[0]?.id ?? null;
}
export async function upsertChannelRecord(input) {
    const existingId = await findRecordByExternalId(input.workspaceId, input.resourceType, input.externalId);
    if (!existingId) {
        return recordRepo.createRecord(input.workspaceId, input.resourceType, input.userId, {
            name: input.name,
            description: input.description ?? null,
            status: input.status ?? 'active',
            stage: input.stage ?? null,
            externalId: input.externalId,
            tags: input.tags ?? [],
            data: input.data ?? {},
        });
    }
    const updated = await recordRepo.updateRecord(input.workspaceId, input.resourceType, existingId, input.userId, {
        name: input.name,
        description: input.description ?? null,
        status: input.status ?? 'active',
        stage: input.stage ?? null,
        externalId: input.externalId,
        tags: input.tags ?? [],
        data: input.data ?? {},
    });
    if (updated.status !== 'updated') {
        throw new Error(`Search intelligence record ${existingId} could not be updated`);
    }
    return updated.record;
}
//# sourceMappingURL=search-intelligence.repo.js.map