function objectValue(value) {
    return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
}
export function generationActivities(preview) {
    const values = Array.isArray(preview?.activity) ? preview.activity : [];
    return values.map(objectValue).map((value) => ({
        id: String(value.id ?? ''),
        code: String(value.code ?? ''),
        tone: ['success', 'warning', 'error'].includes(String(value.tone)) ? String(value.tone) : 'info',
        params: Object.fromEntries(Object.entries(objectValue(value.params)).filter(([, item]) => typeof item === 'string' || typeof item === 'number')),
        createdAt: String(value.createdAt ?? ''),
    })).filter((event) => event.id && event.code);
}
export function appendGenerationActivity(preview, event) {
    const current = generationActivities(preview);
    if (current.some((item) => item.id === event.id))
        return { ...(preview ?? {}), activity: current };
    const activity = [...current, { ...event, createdAt: event.createdAt ?? new Date().toISOString() }].slice(-100);
    return { ...(preview ?? {}), activity };
}
//# sourceMappingURL=website.activity.js.map