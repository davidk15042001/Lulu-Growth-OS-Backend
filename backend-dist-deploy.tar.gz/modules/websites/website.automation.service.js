import { AppError } from '../../utils/app-error.js';
import { firstWebflowSiteWithCollection, wordpressMedia, wordpressSites } from './website.provider.service.js';
import { logger } from '../../config/logger.js';
import * as repo from './website.repo.js';
import { generateWebsitePlan } from './website.generation.service.js';
import { publishWebsiteJob } from './website.publish.service.js';
import * as onboardingRepo from '../onboarding/onboarding.repo.js';
import { appendGenerationActivity } from './website.activity.js';
export const DEFAULT_WEBSITE_PROMPT = `Create factual, conversion-focused website copy from verified Lulu workspace data for the fixed Lulu Standard template. Generate only structured text and SEO content. The application owns the layout, pages, colors and HTML rendering. Never invent names, prices, locations, contacts, certifications, statistics, testimonials, customers, integrations or legal claims. Omit unsupported specifics and never publish placeholders, construction notices, fake contact details or example-company content.`;
function wordpressImageAssets(value) {
    const items = Array.isArray(value) ? value : [];
    return items.map((item) => item && typeof item === 'object' ? item : {}).map((item) => {
        const metadata = item.metadata && typeof item.metadata === 'object' ? item.metadata : {};
        const url = String(item.URL ?? item.url ?? item.source_url ?? metadata.file ?? '').trim();
        const altText = String(item.alt ?? item.alt_text ?? item.caption ?? item.title ?? '').replace(/<[^>]+>/g, '').trim();
        return { url, altText: altText || 'Company image' };
    }).filter((asset) => /^https?:\/\//i.test(asset.url)).slice(0, 8);
}
export async function resetWebsiteProviderState(workspaceId, provider) {
    await repo.deleteSitesByProvider(workspaceId, provider).catch(() => undefined);
    await onboardingRepo.removePlatformByIntegration(workspaceId, provider).catch(() => undefined);
}
export async function disconnectWebsiteProvider(workspaceId, provider) {
    // Remove both the OAuth/platform record and cached website rows. Keeping the
    // latter makes a deleted external site reappear as a stale local fallback.
    await repo.deleteSitesByProvider(workspaceId, provider).catch(() => undefined);
    await onboardingRepo.removePlatformByIntegration(workspaceId, provider).catch(() => undefined);
}
async function getOrCreateProviderSite(workspaceId, provider, selectedSiteId) {
    if (selectedSiteId) {
        const selected = await repo.getSite(workspaceId, selectedSiteId);
        if (!selected || selected.provider !== provider)
            throw new AppError(404, 'WEBSITE_SITE_NOT_FOUND', 'The selected website could not be found for this provider');
        return selected;
    }
    const localSites = await repo.listSites(workspaceId);
    const localProviderSites = localSites.filter((site) => site.provider === provider && site.externalSiteId && site.status !== 'error');
    if (localProviderSites.length === 1)
        return localProviderSites[0];
    if (localProviderSites.length > 1)
        throw new AppError(409, 'WEBSITE_PROVIDER_SITE_SELECTION_REQUIRED', 'Select a WordPress website before starting generation');
    if (provider === 'wordpress')
        throw new AppError(409, 'WEBSITE_PROVIDER_NO_SITE_AVAILABLE', 'No synchronized WordPress website is available. Refresh the provider sites and select one before generating.');
    const target = await firstWebflowSiteWithCollection(workspaceId);
    const existing = await repo.findSiteByExternalSiteId(workspaceId, provider, target.id);
    if (existing)
        return existing;
    const site = await repo.createSite({ workspaceId, provider, ownershipMode: 'connected', name: target.name, externalSiteId: target.id, externalSiteUrl: target.url });
    if (!site)
        throw new AppError(500, 'WEBSITE_SITE_CREATE_FAILED', 'The connected Webflow site could not be registered');
    return repo.updateSiteSettings(site.workspaceId, site.id, { collectionId: target.collectionId });
}
function shouldDisconnectProvider(error) {
    if (!(error instanceof AppError))
        return false;
    if (['WEBSITE_PROVIDER_NOT_CONNECTED', 'WEBSITE_PROVIDER_TOKEN_INVALID', 'WEBSITE_PROVIDER_WRITE_SCOPE_MISSING'].includes(error.code))
        return true;
    if (error.code !== 'WEBSITE_PROVIDER_REQUEST_FAILED' || !error.details || typeof error.details !== 'object')
        return false;
    const status = error.details.providerHttpStatus;
    return status === 401 || status === 403;
}
function generationErrorMessage(error) {
    if (!(error instanceof AppError))
        return error instanceof Error ? error.message : 'Automatic website generation failed';
    const details = error.details && typeof error.details === 'object' ? error.details : {};
    const providerStatus = details.providerHttpStatus;
    const providerCode = details.providerCode;
    const providerMessage = details.providerMessage;
    const diagnostic = [
        typeof providerStatus === 'number' ? `HTTP ${providerStatus}` : null,
        typeof providerCode === 'string' && providerCode ? `Code: ${providerCode}` : null,
        typeof providerMessage === 'string' && providerMessage ? providerMessage : null,
    ].filter(Boolean).join(' · ');
    return diagnostic ? `${error.message} (${diagnostic})` : error.message;
}
async function assertGenerationNotCancelled(siteId, jobId) {
    const job = await repo.getJob(siteId, jobId);
    if (job?.status === 'cancelled') {
        throw new AppError(409, 'WEBSITE_GENERATION_CANCELLED', 'Website generation was cancelled by the user');
    }
    return job;
}
export async function processWebsiteGenerationWorkItem(input, workerId) {
    let heartbeatRunning = false;
    const heartbeat = async () => {
        if (heartbeatRunning)
            return;
        heartbeatRunning = true;
        try {
            await repo.heartbeatJob(input.siteId, input.id, workerId);
        }
        catch (error) {
            logger.error({ jobId: input.id, siteId: input.siteId, workerId, error: error instanceof Error ? error.message : String(error) }, 'Website generation heartbeat failed');
        }
        finally {
            heartbeatRunning = false;
        }
    };
    const heartbeatTimer = setInterval(() => void heartbeat(), 15_000);
    heartbeatTimer.unref();
    try {
        if (!input.createdBy)
            throw new AppError(409, 'WEBSITE_GENERATION_USER_MISSING', 'The user who started this website generation no longer exists');
        await assertGenerationNotCancelled(input.siteId, input.id);
        await repo.updateSiteStatus(input.workspaceId, input.siteId, 'generating');
        const storedProgress = input.preview?.progress && typeof input.preview.progress === 'object'
            ? input.preview.progress
            : {};
        const resuming = Object.keys(input.plan ?? {}).length > 0;
        const initialPreview = {
            ...input.preview,
            provider: input.provider,
            automatic: input.autoPublish,
            progress: resuming
                ? { ...storedProgress, phase: 'resuming', percent: typeof storedProgress.percent === 'number' ? storedProgress.percent : 5 }
                : { phase: 'analyzing_company', percent: 5, completedPages: 0, totalPages: 4, currentPageTitle: null, completedSections: 0, totalSections: 0, currentSectionTitle: null },
        };
        let previewState = resuming
            ? initialPreview
            : appendGenerationActivity(initialPreview, { id: 'job-started', code: 'job_started', tone: 'info', params: {} });
        await repo.updateJob(input.siteId, input.id, {
            status: 'planning',
            preview: previewState,
        });
        let imageAssets = [];
        const generationSite = await repo.getSite(input.workspaceId, input.siteId);
        if (input.provider === 'wordpress' && generationSite?.externalSiteId) {
            try {
                imageAssets = wordpressImageAssets(await wordpressMedia(input.workspaceId, generationSite.externalSiteId));
            }
            catch (error) {
                logger.warn({ jobId: input.id, siteId: input.siteId, error: error instanceof Error ? error.message : String(error) }, 'WordPress media could not be loaded; rendering the standard template without images');
            }
        }
        const plan = await generateWebsitePlan({
            workspaceId: input.workspaceId,
            userId: input.createdBy,
            prompt: input.prompt,
            provider: input.provider,
            existingPlan: input.plan,
            imageAssets,
            ...(input.requestedLanguage ? { language: input.requestedLanguage } : {}),
            onProgress: async (progress) => {
                await assertGenerationNotCancelled(input.siteId, input.id);
                const nextPreview = {
                    ...previewState,
                    provider: input.provider,
                    automatic: input.autoPublish,
                    progress: {
                        phase: progress.phase,
                        percent: progress.percent,
                        completedPages: progress.completedPages,
                        totalPages: progress.totalPages,
                        currentPageTitle: progress.currentPageTitle,
                        completedSections: progress.completedSections,
                        totalSections: progress.totalSections,
                        currentSectionTitle: progress.currentSectionTitle,
                    },
                };
                previewState = progress.activity ? appendGenerationActivity(nextPreview, progress.activity) : nextPreview;
                const updated = await repo.updateJob(input.siteId, input.id, {
                    status: 'planning',
                    ...(progress.plan ? { plan: progress.plan } : {}),
                    preview: previewState,
                });
                if (!updated)
                    await assertGenerationNotCancelled(input.siteId, input.id);
            },
        });
        await assertGenerationNotCancelled(input.siteId, input.id);
        previewState = appendGenerationActivity({
            ...previewState,
            provider: input.provider,
            automatic: input.autoPublish,
            progress: { phase: input.autoPublish ? 'publishing' : 'preview_ready', percent: input.autoPublish ? 55 : 100, completedPages: plan.pages.length, totalPages: plan.pages.length, currentPageTitle: null, completedSections: plan.pages.reduce((total, page) => total + page.generatedSections.length, 0), totalSections: plan.pages.reduce((total, page) => total + page.generatedSections.length, 0), currentSectionTitle: null },
            pages: plan.pages.map((page) => ({ title: page.title, slug: page.slug, seoTitle: page.seoTitle, seoDescription: page.seoDescription })),
        }, { id: 'preview-ready', code: 'preview_ready', tone: 'success', params: { pages: plan.pages.length } });
        const previewJob = await repo.updateJob(input.siteId, input.id, {
            status: 'preview',
            plan,
            preview: previewState,
        });
        if (!previewJob)
            await assertGenerationNotCancelled(input.siteId, input.id);
        if (input.autoPublish) {
            await publishWebsiteJob(input.workspaceId, input.siteId, input.id);
            if (input.provider === 'wordpress' || input.provider === 'webflow')
                await onboardingRepo.markPlatformConnected(input.workspaceId, input.provider);
        }
        else {
            await repo.updateSiteStatus(input.workspaceId, input.siteId, 'preview');
        }
    }
    catch (error) {
        if (error instanceof AppError && error.code === 'WEBSITE_GENERATION_CANCELLED') {
            const cancelledJob = await repo.getJob(input.siteId, input.id).catch(() => null);
            const partialPages = Array.isArray(cancelledJob?.providerResult?.pages)
                ? cancelledJob.providerResult.pages.length
                : 0;
            await repo.updateSiteStatus(input.workspaceId, input.siteId, partialPages > 0 ? 'preview' : 'connected').catch(() => undefined);
            logger.info({ jobId: input.id, siteId: input.siteId, partialPages }, 'Website generation job cancelled');
            return;
        }
        const errorDetails = error instanceof AppError && error.details && typeof error.details === 'object'
            ? error.details
            : undefined;
        logger.error({ jobId: input.id, siteId: input.siteId, provider: input.provider, error: error instanceof Error ? { name: error.name, message: error.message, details: errorDetails } : String(error) }, 'Website generation job failed');
        await repo.updateSiteStatus(input.workspaceId, input.siteId, 'error').catch(() => undefined);
        const message = generationErrorMessage(error);
        const errorCode = error instanceof AppError ? error.code : 'WEBSITE_AUTO_GENERATION_FAILED';
        const currentJob = await repo.getJob(input.siteId, input.id).catch(() => null);
        try {
            await repo.updateJob(input.siteId, input.id, {
                status: 'failed',
                errorCode,
                errorMessage: message,
                ...(currentJob ? { preview: appendGenerationActivity(currentJob.preview, { id: `generation-failed:${currentJob.attemptCount}`, code: 'generation_failed', tone: 'error', params: { message } }) } : {}),
                ...(errorDetails ? { providerResult: { ...(currentJob?.providerResult ?? {}), failureDetails: errorDetails } } : {}),
            });
        }
        catch (persistenceError) {
            logger.error({
                jobId: input.id,
                siteId: input.siteId,
                originalError: error instanceof Error ? error.message : String(error),
                persistenceError: persistenceError instanceof Error ? persistenceError.message : String(persistenceError),
            }, 'Website generation failure status could not be persisted');
            try {
                await repo.markGenerationJobFailed(input.siteId, input.id, errorCode, message);
            }
            catch (fallbackError) {
                logger.fatal({
                    jobId: input.id,
                    siteId: input.siteId,
                    originalError: error instanceof Error ? error.message : String(error),
                    persistenceError: persistenceError instanceof Error ? persistenceError.message : String(persistenceError),
                    fallbackError: fallbackError instanceof Error ? fallbackError.message : String(fallbackError),
                }, 'Website generation failure fallback could not be persisted');
            }
        }
        if (shouldDisconnectProvider(error) && (input.provider === 'wordpress' || input.provider === 'webflow'))
            await disconnectWebsiteProvider(input.workspaceId, input.provider);
    }
    finally {
        clearInterval(heartbeatTimer);
        await repo.releaseJob(input.siteId, input.id, workerId).catch(() => undefined);
    }
}
export async function syncWordpressProviderSites(workspaceId) {
    const data = await wordpressSites(workspaceId);
    const rawSites = Array.isArray(data) ? data : Array.isArray(data?.sites) ? data.sites : [];
    const discovered = rawSites.map((value) => value).map((site) => ({
        id: String(site.ID ?? site.id ?? '').trim(),
        name: String(site.name ?? site.title ?? site.URL ?? site.domain ?? 'WordPress site').trim(),
        url: site.URL ?? site.url ?? site.link ?? null,
    })).filter((site) => site.id);
    await repo.deleteSitesByProviderExcept(workspaceId, 'wordpress', discovered.map((site) => site.id));
    for (const site of discovered) {
        const existing = await repo.findSiteByExternalSiteId(workspaceId, 'wordpress', site.id);
        if (existing)
            await repo.updateSiteExternalDetails(workspaceId, existing.id, site.name, typeof site.url === 'string' ? site.url : undefined);
        else
            await repo.createSite({ workspaceId, provider: 'wordpress', ownershipMode: 'connected', name: site.name, externalSiteId: site.id, externalSiteUrl: typeof site.url === 'string' ? site.url : undefined });
    }
    return repo.listSites(workspaceId);
}
export async function startAutomaticWebsiteGeneration(input) {
    try {
        if (input.provider === 'wordpress' && !input.siteId) {
            throw new AppError(409, 'WEBSITE_PROVIDER_SITE_SELECTION_REQUIRED', 'Select the WordPress website that should receive the generated content');
        }
        let site = await getOrCreateProviderSite(input.workspaceId, input.provider, input.siteId);
        if (!site)
            throw new AppError(500, 'WEBSITE_SITE_CREATE_FAILED', 'The connected provider site could not be registered');
        const active = await repo.findActiveJob(site.id);
        if (active)
            return { site, job: active, reused: true };
        const cancelled = await repo.findLatestCancelledJob(site.id);
        if (cancelled && cancelled.preview?.targetMode === input.targetMode) {
            const resumed = await repo.resumeJob(site.id, cancelled.id);
            if (resumed.job)
                return { site, job: resumed.job, reused: true };
        }
        site = await repo.updateSiteSettings(input.workspaceId, site.id, {
            generationTargetMode: input.targetMode,
            generationTargetConfirmedAt: new Date().toISOString(),
        }) ?? site;
        const initialPreview = appendGenerationActivity({ targetMode: input.targetMode }, {
            id: `target-selected:${input.targetMode}`,
            code: input.targetMode === 'new' ? 'target_new_selected' : 'target_existing_selected',
            tone: 'info',
            params: { mode: input.targetMode, site: site.name },
        });
        const created = await repo.createJob({
            siteId: site.id,
            prompt: DEFAULT_WEBSITE_PROMPT,
            createdBy: input.userId,
            autoPublish: true,
            preview: initialPreview,
            ...(input.language ? { requestedLanguage: input.language } : {}),
        });
        if (!created.job)
            throw new AppError(500, 'WEBSITE_GENERATION_JOB_CREATE_FAILED', 'The automatic website generation job could not be created');
        return { site, job: created.job, reused: !created.created };
    }
    catch (error) {
        if (shouldDisconnectProvider(error))
            await resetWebsiteProviderState(input.workspaceId, input.provider);
        throw error;
    }
}
export async function getActiveWebsiteGenerationJob(input) {
    const site = await repo.getSite(input.workspaceId, input.siteId);
    if (!site)
        throw new AppError(404, 'WEBSITE_SITE_NOT_FOUND', 'The selected website could not be found');
    return repo.findActiveJob(site.id);
}
//# sourceMappingURL=website.automation.service.js.map