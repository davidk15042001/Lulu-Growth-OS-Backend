import { env, hasAiProvider } from '../../config/env.js';
import { conflictError, notFoundError } from '../../utils/app-error.js';
import { sendWorkspaceInvitationEmail } from '../../utils/mailer.js';
import * as workspaceService from '../workspaces/workspace.service.js';
import * as repo from './workspace-app.repo.js';
export async function getBootstrap(workspaceId, userId) {
    const [workspace, statistics] = await Promise.all([
        workspaceService.getWorkspace(workspaceId, userId),
        repo.getBootstrapStats(workspaceId, userId),
    ]);
    return {
        workspace,
        permissions: {
            role: workspace.role,
            canEdit: workspace.role !== 'viewer',
            canAdminister: workspace.role === 'owner' || workspace.role === 'admin',
        },
        capabilities: {
            aiGeneration: hasAiProvider,
            transactionalEmail: !!env.MAILCOW_SMTP_HOST && !!env.MAILCOW_SMTP_USER && !!env.MAILCOW_SMTP_PASS,
        },
        ...statistics,
    };
}
export function listMembers(workspaceId) {
    return repo.listMembers(workspaceId);
}
export async function inviteMember(workspaceId, userId, input) {
    const workspace = await workspaceService.getWorkspace(workspaceId, userId);
    const result = await repo.createInvitation(workspaceId, userId, input);
    if (!result.invitation)
        throw new Error('Invitation insert did not return a row');
    const baseUrl = env.FRONTEND_BASE_URL ?? 'http://localhost:5173';
    const invitationUrl = `${baseUrl.replace(/\/$/, '')}/auth/invitations/${encodeURIComponent(result.token)}`;
    await sendWorkspaceInvitationEmail(input.email, workspace.companyName, invitationUrl);
    return result.invitation;
}
export async function acceptInvitation(token, userId, userEmail) {
    const invitation = await repo.acceptInvitation(token, userId, userEmail);
    if (!invitation)
        throw notFoundError('Invitation is invalid, expired, or belongs to another account');
    return invitation;
}
export async function updateMember(workspaceId, memberId, input) {
    const member = await repo.updateMember(workspaceId, memberId, input);
    if (!member)
        throw conflictError('Workspace owners cannot be reassigned or the member does not exist');
    return member;
}
export async function removeMember(workspaceId, memberId) {
    if (!(await repo.removeMember(workspaceId, memberId))) {
        throw conflictError('Workspace owners cannot be removed or the member does not exist');
    }
}
export function listSavedViews(workspaceId, userId, filters) {
    return repo.listSavedViews(workspaceId, userId, filters);
}
export function createSavedView(workspaceId, userId, input) {
    return repo.createSavedView(workspaceId, userId, input);
}
export async function updateSavedView(workspaceId, userId, viewId, input) {
    const view = await repo.updateSavedView(workspaceId, userId, viewId, input);
    if (!view)
        throw notFoundError('Saved view not found');
    return view;
}
export async function deleteSavedView(workspaceId, userId, viewId) {
    if (!(await repo.deleteSavedView(workspaceId, userId, viewId)))
        throw notFoundError('Saved view not found');
}
export function listAudit(workspaceId, filters) {
    return repo.listAudit(workspaceId, filters);
}
export function getBilling(workspaceId, filters) {
    return repo.getBilling(workspaceId, filters);
}
export async function queueIntegrationSync(workspaceId, platformId) {
    const run = await repo.queueIntegrationSync(workspaceId, platformId);
    if (!run)
        throw notFoundError('Integration not found');
    return run;
}
//# sourceMappingURL=workspace-app.service.js.map