import { z } from 'zod';
import { createdResponse, successResponse } from '../../utils/response.js';
import * as service from './workspace-app.service.js';
import { createCheckout, syncCheckoutStatus } from '../billing/airwallex.service.js';
import * as contentGeneration from '../content-generation/content-generation.service.js';
import { CONTENT_MODULES } from '../content-generation/content-generation.repo.js';
import { createSavedViewSchema, inviteMemberSchema, inviteTokenParamsSchema, listAuditQuerySchema, listSavedViewsQuerySchema, listUsageQuerySchema, updateMemberSchema, updateSavedViewSchema, workspaceAppParamsSchema, } from './workspace-app.validator.js';
function params(req) {
    return workspaceAppParamsSchema.parse(req.params);
}
export async function bootstrap(req, res, next) {
    try {
        const { workspaceId } = params(req);
        return successResponse(res, 'Workspace application state loaded', await service.getBootstrap(workspaceId, req.user.id));
    }
    catch (error) {
        next(error);
    }
}
export async function members(req, res, next) {
    try {
        const { workspaceId } = params(req);
        return successResponse(res, 'Workspace members loaded', await service.listMembers(workspaceId));
    }
    catch (error) {
        next(error);
    }
}
export async function invite(req, res, next) {
    try {
        const { workspaceId } = params(req);
        const input = inviteMemberSchema.parse(req.body);
        return createdResponse(res, 'Workspace invitation sent', await service.inviteMember(workspaceId, req.user.id, input));
    }
    catch (error) {
        next(error);
    }
}
export async function acceptInvitation(req, res, next) {
    try {
        const { token } = inviteTokenParamsSchema.parse(req.params);
        const invitation = await service.acceptInvitation(token, req.user.id, req.user.email);
        return successResponse(res, 'Workspace invitation accepted', invitation);
    }
    catch (error) {
        next(error);
    }
}
export async function updateMember(req, res, next) {
    try {
        const { workspaceId, memberId } = params(req);
        const member = await service.updateMember(workspaceId, memberId, updateMemberSchema.parse(req.body));
        return successResponse(res, 'Workspace member updated', member);
    }
    catch (error) {
        next(error);
    }
}
export async function removeMember(req, res, next) {
    try {
        const { workspaceId, memberId } = params(req);
        await service.removeMember(workspaceId, memberId);
        return successResponse(res, 'Workspace member removed');
    }
    catch (error) {
        next(error);
    }
}
export async function savedViews(req, res, next) {
    try {
        const { workspaceId } = params(req);
        const filters = listSavedViewsQuerySchema.parse(req.query);
        return successResponse(res, 'Saved views loaded', { items: await service.listSavedViews(workspaceId, req.user.id, filters) });
    }
    catch (error) {
        next(error);
    }
}
export async function createSavedView(req, res, next) {
    try {
        const { workspaceId } = params(req);
        const view = await service.createSavedView(workspaceId, req.user.id, createSavedViewSchema.parse(req.body));
        return createdResponse(res, 'Saved view created', view);
    }
    catch (error) {
        next(error);
    }
}
export async function updateSavedView(req, res, next) {
    try {
        const { workspaceId, viewId } = params(req);
        const view = await service.updateSavedView(workspaceId, req.user.id, viewId, updateSavedViewSchema.parse(req.body));
        return successResponse(res, 'Saved view updated', view);
    }
    catch (error) {
        next(error);
    }
}
export async function deleteSavedView(req, res, next) {
    try {
        const { workspaceId, viewId } = params(req);
        await service.deleteSavedView(workspaceId, req.user.id, viewId);
        return successResponse(res, 'Saved view deleted');
    }
    catch (error) {
        next(error);
    }
}
export async function audit(req, res, next) {
    try {
        const { workspaceId } = params(req);
        return successResponse(res, 'Audit trail loaded', await service.listAudit(workspaceId, listAuditQuerySchema.parse(req.query)));
    }
    catch (error) {
        next(error);
    }
}
export async function createBillingCheckout(req, res, next) {
    try {
        const { workspaceId } = params(req);
        const input = z.object({
            planKey: z.enum(['viewer', 'starter', 'ai', 'test']),
            successUrl: z.string().url(),
            backUrl: z.string().url(),
            password: z.string().max(128).optional(),
        }).parse(req.body);
        return successResponse(res, 'Billing checkout created', await createCheckout({ workspaceId, planKey: input.planKey, successUrl: input.successUrl, backUrl: input.backUrl, ...(req.user?.email ? { customerEmail: req.user.email } : {}), ...(input.password ? { password: input.password } : {}) }));
    }
    catch (error) {
        next(error);
    }
}
export async function syncBillingCheckout(req, res, next) {
    try {
        const { workspaceId } = params(req);
        const rawCheckoutId = req.params.checkoutId;
        const checkoutId = Array.isArray(rawCheckoutId) ? rawCheckoutId[0] : rawCheckoutId;
        if (!checkoutId)
            throw new Error('Billing checkout ID is required');
        return successResponse(res, 'Billing checkout status synchronized', await syncCheckoutStatus(workspaceId, checkoutId));
    }
    catch (error) {
        next(error);
    }
}
export async function billing(req, res, next) {
    try {
        const { workspaceId } = params(req);
        return successResponse(res, 'Billing state loaded', await service.getBilling(workspaceId, listUsageQuerySchema.parse(req.query)));
    }
    catch (error) {
        next(error);
    }
}
export async function startContentRefresh(req, res, next) {
    try {
        const { workspaceId } = params(req);
        const requested = Array.isArray(req.body?.modules) ? req.body.modules.filter((value) => CONTENT_MODULES.includes(value)) : [...CONTENT_MODULES];
        return createdResponse(res, 'Workspace content refresh started', await contentGeneration.startContentRefresh(workspaceId, req.user.id, requested));
    }
    catch (error) {
        next(error);
    }
}
export async function contentRefreshStatus(req, res, next) {
    try {
        const { workspaceId } = params(req);
        return successResponse(res, 'Workspace content refresh status loaded', await contentGeneration.getContentRefresh(workspaceId, String(req.params.jobId)));
    }
    catch (error) {
        next(error);
    }
}
export async function contentAssets(req, res, next) {
    try {
        const { workspaceId } = params(req);
        const rawModule = typeof req.query.module === 'string' ? req.query.module : undefined;
        const module = CONTENT_MODULES.includes(rawModule) ? rawModule : undefined;
        return successResponse(res, 'Workspace content assets loaded', { items: await contentGeneration.listContentAssets(workspaceId, module) });
    }
    catch (error) {
        next(error);
    }
}
export async function syncIntegration(req, res, next) {
    try {
        const { workspaceId, platformId } = params(req);
        return createdResponse(res, 'Integration sync queued', await service.queueIntegrationSync(workspaceId, platformId));
    }
    catch (error) {
        next(error);
    }
}
//# sourceMappingURL=workspace-app.controller.js.map