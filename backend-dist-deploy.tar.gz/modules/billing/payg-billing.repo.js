import { query, withTransaction } from '../../db/pool.js';
import { AppError } from '../../utils/app-error.js';
const nextBerlinMondaySql = `(date_trunc('week', NOW() AT TIME ZONE 'Europe/Berlin') + INTERVAL '7 days') AT TIME ZONE 'Europe/Berlin'`;
const currentBerlinMondaySql = `date_trunc('week', NOW() AT TIME ZONE 'Europe/Berlin') AT TIME ZONE 'Europe/Berlin'`;
export const AWS_USAGE_CUSTOMER_MULTIPLIER = 2;
export async function ensurePaygProfile(workspaceId, paymentSourceId) {
    await query(`INSERT INTO workspace_payg_profiles (
       workspace_id, interval_days, current_period_start, current_period_end,
       provider_payment_source_id, collection_method
     ) VALUES ($1, 7, ${currentBerlinMondaySql}, ${nextBerlinMondaySql}, $2,
       CASE WHEN $2::text IS NULL THEN 'CHARGE_ON_CHECKOUT' ELSE 'AUTO_CHARGE' END)
     ON CONFLICT (workspace_id) DO UPDATE SET
       enabled=TRUE,
       interval_days=7,
       provider_payment_source_id=COALESCE(EXCLUDED.provider_payment_source_id, workspace_payg_profiles.provider_payment_source_id),
       collection_method=CASE
         WHEN COALESCE(EXCLUDED.provider_payment_source_id, workspace_payg_profiles.provider_payment_source_id) IS NULL
           THEN 'CHARGE_ON_CHECKOUT'
         ELSE 'AUTO_CHARGE'
       END,
       ai_access_blocked=CASE
         WHEN $2::text IS NOT NULL AND workspace_payg_profiles.block_reason='PAYMENT_SOURCE_SETUP_REQUIRED' THEN FALSE
         ELSE workspace_payg_profiles.ai_access_blocked
       END,
       blocked_at=CASE
         WHEN $2::text IS NOT NULL AND workspace_payg_profiles.block_reason='PAYMENT_SOURCE_SETUP_REQUIRED' THEN NULL
         ELSE workspace_payg_profiles.blocked_at
       END,
       block_reason=CASE
         WHEN $2::text IS NOT NULL AND workspace_payg_profiles.block_reason='PAYMENT_SOURCE_SETUP_REQUIRED' THEN NULL
         ELSE workspace_payg_profiles.block_reason
       END,
       blocked_period_id=CASE
         WHEN $2::text IS NOT NULL AND workspace_payg_profiles.block_reason='PAYMENT_SOURCE_SETUP_REQUIRED' THEN NULL
         ELSE workspace_payg_profiles.blocked_period_id
       END`, [workspaceId, paymentSourceId ?? null]);
}
export async function allocateDailyServerUsage(providerCostUsd, customerCostUsd) {
    if (customerCostUsd <= 0)
        return 0;
    const result = await query(`INSERT INTO workspace_server_usage_ledger (
       workspace_id, usage_date, provider_cost_usd, customer_cost_usd,
       metadata
     )
     SELECT p.workspace_id, CURRENT_DATE, $1, $2,
            jsonb_build_object('source', 'daily-server-allocation')
     FROM workspace_payg_profiles p
     JOIN workspace_subscriptions s ON s.workspace_id=p.workspace_id
     WHERE p.enabled=TRUE
       AND s.provider='airwallex'
       AND s.status='active'
       AND s.plan_key IN ('starter', 'ai', 'test')
     ON CONFLICT (workspace_id, usage_date) DO NOTHING`, [providerCostUsd, customerCostUsd]);
    return result.rowCount;
}
async function advanceCompletedProfile(client, workspaceId, periodStart, periodEnd) {
    await query(`UPDATE workspace_payg_profiles
     SET current_period_start=$3::timestamptz,
         current_period_end=(
           date_trunc('week', $3::timestamptz AT TIME ZONE 'Europe/Berlin') + INTERVAL '7 days'
         ) AT TIME ZONE 'Europe/Berlin'
     WHERE workspace_id=$1
       AND current_period_start=$2::timestamptz
       AND current_period_end=$3::timestamptz`, [workspaceId, periodStart, periodEnd], client);
}
export async function repairCompletedProfilePointers() {
    const result = await query(`UPDATE workspace_payg_profiles p
     SET current_period_start=finished.period_end,
         current_period_end=(
           date_trunc('week', finished.period_end AT TIME ZONE 'Europe/Berlin') + INTERVAL '7 days'
         ) AT TIME ZONE 'Europe/Berlin'
     FROM workspace_payg_periods finished
     WHERE finished.workspace_id=p.workspace_id
       AND finished.period_start=p.current_period_start
       AND finished.period_end=p.current_period_end
       AND finished.status IN ('payment_due', 'payment_failed', 'paid', 'skipped')
       AND p.current_period_end <= NOW()`);
    return result.rowCount;
}
export async function claimDuePaygPeriod() {
    return withTransaction(async (client) => {
        const profile = await query(`SELECT p.workspace_id AS "workspaceId",
              p.current_period_start AS "periodStart",
              p.current_period_end AS "periodEnd",
              p.currency,
              s.provider_customer_id AS "providerCustomerId",
              COALESCE(p.provider_payment_source_id, s.metadata->>'paymentSourceId') AS "paymentSourceId"
       FROM workspace_payg_profiles p
       JOIN workspace_subscriptions s ON s.workspace_id=p.workspace_id
       WHERE p.enabled=TRUE
         AND p.current_period_end <= NOW()
         AND s.provider='airwallex'
         AND s.status='active'
         AND s.plan_key IN ('starter', 'ai', 'test')
         AND s.provider_customer_id IS NOT NULL
         AND NOT EXISTS (
           SELECT 1 FROM workspace_payg_periods active
           WHERE active.workspace_id=p.workspace_id
             AND active.period_start=p.current_period_start
             AND active.period_end=p.current_period_end
             AND active.status='processing'
             AND active.processing_started_at > NOW() - INTERVAL '30 minutes'
         )
       ORDER BY p.current_period_end, p.workspace_id
       FOR UPDATE OF p SKIP LOCKED
       LIMIT 1`, [], client);
        const selected = profile.rows[0];
        if (!selected)
            return null;
        const period = await query(`INSERT INTO workspace_payg_periods (
         workspace_id, period_start, period_end, currency, status
       ) VALUES ($1, $2, $3, $4, 'processing')
       ON CONFLICT (workspace_id, period_start, period_end) DO UPDATE SET
         status='processing',
         processing_started_at=NOW(),
         attempt_count=workspace_payg_periods.attempt_count + 1,
         last_error_code=NULL,
         last_error_message=NULL
       WHERE workspace_payg_periods.status='failed'
          OR (workspace_payg_periods.status='processing'
              AND workspace_payg_periods.processing_started_at <= NOW() - INTERVAL '30 minutes')
       RETURNING id, provider_invoice_id AS "providerInvoiceId",
                 line_items_added_at AS "lineItemsAddedAt",
                 finalized_at AS "finalizedAt"`, [selected.workspaceId, selected.periodStart, selected.periodEnd, selected.currency], client);
        const claimed = period.rows[0];
        if (!claimed)
            return null;
        await query(`UPDATE ai_usage_ledger
       SET payg_period_id=$1
       WHERE workspace_id=$2
         AND payg_period_id IS NULL
         AND created_at >= $3::timestamptz
         AND created_at < $4::timestamptz`, [claimed.id, selected.workspaceId, selected.periodStart, selected.periodEnd], client);
        await query(`UPDATE workspace_server_usage_ledger
       SET payg_period_id=$1
       WHERE workspace_id=$2
         AND payg_period_id IS NULL
         AND created_at >= $3::timestamptz
         AND created_at < $4::timestamptz`, [claimed.id, selected.workspaceId, selected.periodStart, selected.periodEnd], client);
        const totals = await query(`SELECT
         COALESCE((SELECT SUM(customer_cost_usd) FROM ai_usage_ledger WHERE payg_period_id=$1), 0)::numeric AS "apiCostUsd",
         COALESCE((SELECT SUM(customer_cost_usd) FROM workspace_server_usage_ledger WHERE payg_period_id=$1), 0)::numeric AS "serverCostUsd"`, [claimed.id], client);
        const costs = totals.rows[0] ?? { apiCostUsd: '0', serverCostUsd: '0' };
        const updated = await query(`UPDATE workspace_payg_periods
       SET api_cost_usd=$2, server_cost_usd=$3
       WHERE id=$1
       RETURNING total_cost_usd AS "totalCostUsd"`, [claimed.id, costs.apiCostUsd, costs.serverCostUsd], client);
        return {
            ...selected,
            ...claimed,
            periodStart: new Date(selected.periodStart).toISOString(),
            periodEnd: new Date(selected.periodEnd).toISOString(),
            apiCostUsd: costs.apiCostUsd,
            serverCostUsd: costs.serverCostUsd,
            totalCostUsd: updated.rows[0]?.totalCostUsd ?? '0',
        };
    });
}
export async function markPaygPeriodSkipped(period) {
    await withTransaction(async (client) => {
        await query(`UPDATE workspace_payg_periods
       SET status='skipped', finalized_at=NOW(), processing_started_at=NOW()
       WHERE id=$1`, [period.id], client);
        await advanceCompletedProfile(client, period.workspaceId, period.periodStart, period.periodEnd);
    });
}
export async function savePaygProviderInvoice(periodId, invoiceId, hostedUrl) {
    await query(`UPDATE workspace_payg_periods
     SET provider_invoice_id=$2, hosted_invoice_url=COALESCE($3, hosted_invoice_url),
         metadata=metadata || jsonb_build_object('providerInvoiceCreatedAt', NOW())
     WHERE id=$1`, [periodId, invoiceId, hostedUrl ?? null]);
}
export async function markPaygLineItemsAdded(periodId) {
    await query(`UPDATE workspace_payg_periods SET line_items_added_at=NOW() WHERE id=$1`, [periodId]);
}
export async function finalizePaygPeriod(period, invoice, paymentAttempted = false) {
    const paid = String(invoice.payment_status ?? '').toUpperCase() === 'PAID';
    const blockAccess = !paid && (paymentAttempted || !period.paymentSourceId);
    const status = paid ? 'paid' : paymentAttempted ? 'payment_failed' : 'payment_due';
    await withTransaction(async (client) => {
        await query(`UPDATE workspace_payg_periods
       SET status=$2,
           hosted_invoice_url=COALESCE($3, hosted_invoice_url),
           invoice_pdf_url=COALESCE($4, invoice_pdf_url),
           finalized_at=NOW(),
           paid_at=CASE WHEN $2='paid' THEN COALESCE($5::timestamptz, NOW()) ELSE paid_at END,
           processing_started_at=NOW(),
           metadata=metadata || $6::jsonb
       WHERE id=$1`, [period.id, status, invoice.hosted_url ?? null, invoice.pdf_url ?? null, invoice.paid_at ?? null, JSON.stringify({ providerStatus: invoice.status ?? null, providerPaymentStatus: invoice.payment_status ?? null, paymentAttempted })], client);
        if (paid) {
            await clearWorkspaceAiBlock(client, period.workspaceId);
        }
        else if (blockAccess) {
            await blockWorkspaceAi(client, period.workspaceId, period.id, period.paymentSourceId ? 'AUTOMATIC_PAYMENT_FAILED' : 'PAYMENT_SOURCE_REQUIRED');
        }
        await advanceCompletedProfile(client, period.workspaceId, period.periodStart, period.periodEnd);
    });
}
async function blockWorkspaceAi(client, workspaceId, periodId, reason) {
    await query(`UPDATE workspace_payg_profiles
     SET ai_access_blocked=TRUE, blocked_at=COALESCE(blocked_at, NOW()),
         block_reason=$3, blocked_period_id=$2
     WHERE workspace_id=$1`, [workspaceId, periodId, reason], client);
}
async function clearWorkspaceAiBlock(client, workspaceId) {
    await query(`UPDATE workspace_payg_profiles p
     SET ai_access_blocked=FALSE, blocked_at=NULL, block_reason=NULL, blocked_period_id=NULL
     WHERE p.workspace_id=$1
       AND NOT EXISTS (
         SELECT 1 FROM workspace_payg_periods pp
         WHERE pp.workspace_id=p.workspace_id
           AND pp.status IN ('payment_due', 'payment_failed')
           AND pp.paid_at IS NULL
       )`, [workspaceId], client);
}
export async function failPaygPeriod(periodId, code, message) {
    await query(`UPDATE workspace_payg_periods
     SET status='failed', last_error_code=$2, last_error_message=$3,
         processing_started_at=NOW()
     WHERE id=$1`, [periodId, code, message.slice(0, 2000)]);
}
export async function applyPaygInvoiceWebhook(input) {
    const paid = input.paymentStatus.toUpperCase() === 'PAID';
    const failureSignal = `${input.paymentStatus} ${input.eventType ?? ''}`.toUpperCase();
    const failed = !paid && /(FAILED|DECLINED|PAST_DUE|OVERDUE|PAYMENT_FAILURE)/.test(failureSignal);
    return withTransaction(async (client) => {
        const updated = await query(`UPDATE workspace_payg_periods
       SET status=CASE WHEN $3 THEN 'paid' WHEN $8 THEN 'payment_failed' ELSE status END,
           provider_invoice_id=COALESCE($2, provider_invoice_id),
           hosted_invoice_url=COALESCE($4, hosted_invoice_url),
           invoice_pdf_url=COALESCE($5, invoice_pdf_url),
           paid_at=CASE WHEN $3 THEN COALESCE($6::timestamptz, NOW()) ELSE paid_at END,
           metadata=metadata || jsonb_build_object('lastPaymentStatus', $7::text, 'lastPaymentEventType', $9::text)
       WHERE id=$1
       RETURNING workspace_id AS "workspaceId"`, [input.periodId, input.providerInvoiceId ?? null, paid, input.hostedUrl ?? null, input.pdfUrl ?? null, input.paidAt ?? null, input.paymentStatus, failed, input.eventType ?? null], client);
        const workspaceId = updated.rows[0]?.workspaceId;
        if (!workspaceId)
            return false;
        if (input.paymentSourceId) {
            await query(`UPDATE workspace_payg_profiles
         SET provider_payment_source_id=$2, collection_method='AUTO_CHARGE'
         WHERE workspace_id=$1`, [workspaceId, input.paymentSourceId], client);
        }
        if (paid)
            await clearWorkspaceAiBlock(client, workspaceId);
        else if (failed)
            await blockWorkspaceAi(client, workspaceId, input.periodId, 'AUTOMATIC_PAYMENT_FAILED');
        return true;
    });
}
export async function assertAiBillingAccess(workspaceId) {
    const { rows } = await query(`SELECT p.ai_access_blocked AS blocked, p.block_reason AS reason,
            pp.hosted_invoice_url AS "hostedInvoiceUrl",
            pp.invoice_pdf_url AS "invoicePdfUrl"
     FROM workspace_payg_profiles p
     LEFT JOIN workspace_payg_periods pp ON pp.id=p.blocked_period_id
     WHERE p.workspace_id=$1`, [workspaceId]);
    const state = rows[0];
    if (!state?.blocked)
        return;
    throw new AppError(402, 'AI_USAGE_PAYMENT_REQUIRED', 'AI functions are blocked until the outstanding usage invoice is paid.', {
        reason: state.reason,
        paymentLink: state.hostedInvoiceUrl,
        invoicePdfUrl: state.invoicePdfUrl,
    });
}
export async function listUnprovisionedTestBillingCustomers(limit = 25) {
    const { rows } = await query(`SELECT s.workspace_id AS "workspaceId", w.name AS "workspaceName",
            owner.email AS "customerEmail"
     FROM workspace_subscriptions s
     JOIN workspaces w ON w.id=s.workspace_id AND w.deleted_at IS NULL
     LEFT JOIN LATERAL (
       SELECT u.email
       FROM workspace_members wm
       JOIN users u ON u.id=wm.user_id
       WHERE wm.workspace_id=s.workspace_id AND wm.role='owner'
       ORDER BY wm.joined_at
       LIMIT 1
     ) owner ON TRUE
     WHERE s.plan_key='test'
       AND s.status='active'
       AND s.provider_customer_id IS NULL
     ORDER BY s.updated_at
     LIMIT $1`, [limit]);
    return rows;
}
export async function saveTestBillingCustomer(workspaceId, providerCustomerId) {
    await withTransaction(async (client) => {
        await query(`UPDATE workspace_subscriptions
       SET provider='airwallex', provider_customer_id=$2,
           metadata=metadata || jsonb_build_object('paygCustomerProvisionedAt', NOW()), updated_at=NOW()
       WHERE workspace_id=$1 AND plan_key='test' AND status='active'`, [workspaceId, providerCustomerId], client);
    });
    await ensurePaygProfile(workspaceId);
    await query(`UPDATE workspace_payg_profiles
     SET ai_access_blocked=TRUE, blocked_at=COALESCE(blocked_at, NOW()),
         block_reason='PAYMENT_SOURCE_SETUP_REQUIRED'
     WHERE workspace_id=$1 AND provider_payment_source_id IS NULL`, [workspaceId]);
}
//# sourceMappingURL=payg-billing.repo.js.map