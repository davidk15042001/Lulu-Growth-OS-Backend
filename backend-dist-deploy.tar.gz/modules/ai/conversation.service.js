import { notFoundError } from '../../utils/app-error.js';
import * as repo from './conversation.repo.js';
import * as workspaceService from '../workspaces/workspace.service.js';
import * as onboardingRepo from '../onboarding/onboarding.repo.js';
import { generateAssistantResponse, isAiGenerationConfigured, } from './openai.service.js';
import { AppError } from '../../utils/app-error.js';
export const listConversations = (workspaceId, userId, filters) => repo.listConversations(workspaceId, userId, filters);
export async function getConversation(workspaceId, userId, conversationId) {
    const conversation = await repo.findConversation(workspaceId, userId, conversationId);
    if (!conversation)
        throw notFoundError('Conversation not found');
    return conversation;
}
export async function createConversation(workspaceId, userId, input) {
    const id = await repo.createConversation(workspaceId, userId, input);
    if (!id)
        throw new Error('Conversation insert did not return an id');
    return getConversation(workspaceId, userId, id);
}
export async function updateConversation(workspaceId, userId, conversationId, input) {
    if (!(await repo.updateConversation(workspaceId, userId, conversationId, input))) {
        throw notFoundError('Conversation not found');
    }
    return getConversation(workspaceId, userId, conversationId);
}
export async function archiveConversation(workspaceId, userId, conversationId) {
    if (!(await repo.archiveConversation(workspaceId, userId, conversationId))) {
        throw notFoundError('Conversation not found');
    }
}
export const listMessages = (workspaceId, userId, conversationId, filters) => repo.listMessages(workspaceId, userId, conversationId, filters);
export async function createUserMessage(workspaceId, userId, conversationId, input) {
    const message = await repo.createUserMessage(workspaceId, userId, conversationId, input);
    if (!message)
        throw notFoundError('Conversation not found');
    return message;
}
export async function respond(workspaceId, userId, conversationId, input) {
    if (!isAiGenerationConfigured()) {
        throw new AppError(503, 'AI_NOT_CONFIGURED', 'The configured AI provider is not configured');
    }
    const conversation = await getConversation(workspaceId, userId, conversationId);
    const userMessage = await createUserMessage(workspaceId, userId, conversationId, input);
    const [workspace, preferences, turns] = await Promise.all([
        workspaceService.getWorkspace(workspaceId, userId),
        onboardingRepo.getAiPreferences(workspaceId),
        repo.conversationTurns(workspaceId, userId, conversationId),
    ]);
    const generated = await generateAssistantResponse({
        userId,
        workspaceId,
        model: conversation.model,
        turns,
        context: {
            company: {
                name: workspace.companyName,
                industry: workspace.industry,
                businessDescription: workspace.businessDescription,
                valueProposition: workspace.valueProposition,
                targetMarket: workspace.targetMarket,
            },
            preferences: preferences ? {
                priorities: preferences.businessPriorities,
                communicationStyle: preferences.communicationStyle,
                insightDetail: preferences.insightDetail,
                responseLanguage: preferences.responseLanguage,
                actionLevel: preferences.actionLevel,
            } : null,
        },
    });
    const assistantMessage = await repo.appendAssistantMessage(conversationId, generated.content, { providerResponseId: generated.responseId, model: generated.model }, {
        ...(generated.usage.inputTokens === null ? {} : { inputTokens: generated.usage.inputTokens }),
        ...(generated.usage.outputTokens === null ? {} : { outputTokens: generated.usage.outputTokens }),
    });
    return { userMessage, assistantMessage, model: generated.model };
}
//# sourceMappingURL=conversation.service.js.map