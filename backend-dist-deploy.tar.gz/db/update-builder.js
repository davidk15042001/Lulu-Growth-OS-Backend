export function buildUpdateSet(input, columnMap, parameterOffset = 0) {
    const values = [];
    const assignments = [];
    for (const [rawKey, value] of Object.entries(input)) {
        if (value === undefined)
            continue;
        const column = columnMap[rawKey];
        if (!column)
            continue;
        values.push(value);
        assignments.push(`${column} = $${parameterOffset + values.length}`);
    }
    return { assignments, values };
}
//# sourceMappingURL=update-builder.js.map